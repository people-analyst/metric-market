// receive-cards.js — Card Receiver Endpoint for Hub/Agent Card Deployment
// Application: Metric Market (metric-market)
// Generated: 2026-02-12
//
// This module adds a POST /api/receive-cards endpoint to your Express app.
// It allows the Hub AI agent (and other authorized services) to push
// Kanban cards directly to your app's local database.
//
// SETUP:
// 1. Set DEPLOY_SECRET in your Replit Secrets (same value as Hub and Kanban apps)
// 2. Register this route in your Express app (see below)
// 3. Ensure your database has a kanban_cards table (schema provided below)
//
// USAGE:
//   const registerCardReceiver = require("./receive-cards");
//   registerCardReceiver(app, db);  // pass your Express app and db connection
//
// REQUIRED TABLE SCHEMA (PostgreSQL):
//   CREATE TABLE IF NOT EXISTS kanban_cards (
//     id SERIAL PRIMARY KEY,
//     title TEXT NOT NULL,
//     type TEXT DEFAULT 'task',
//     app_target TEXT DEFAULT 'metric-market',
//     status TEXT DEFAULT 'backlog',
//     priority TEXT DEFAULT 'medium',
//     description TEXT,
//     acceptance_criteria JSONB DEFAULT '[]',
//     technical_notes TEXT,
//     estimated_effort TEXT,
//     assigned_to TEXT,
//     dependencies JSONB DEFAULT '[]',
//     tags JSONB DEFAULT '[]',
//     agent_notes TEXT,
//     position INTEGER DEFAULT 0,
//     created_at TIMESTAMP DEFAULT NOW(),
//     updated_at TIMESTAMP DEFAULT NOW()
//   );

module.exports = function registerCardReceiver(app, db) {

  app.post("/api/receive-cards", async (req, res) => {
    try {
      const DEPLOY_SECRET = process.env.DEPLOY_SECRET;
      if (!DEPLOY_SECRET) {
        return res.status(500).json({ error: "DEPLOY_SECRET not configured. Set it in Replit Secrets." });
      }

      const authHeader = req.headers.authorization;
      if (authHeader !== `Bearer ${DEPLOY_SECRET}`) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const { cards, metadata } = req.body;

      if (!Array.isArray(cards) || cards.length === 0) {
        return res.status(400).json({ error: "No cards provided" });
      }

      const VALID_TYPES = ["project", "feature", "task", "bug"];
      const VALID_STATUSES = ["backlog", "todo", "in_progress", "review", "done", "blocked"];
      const VALID_PRIORITIES = ["low", "medium", "high", "critical"];

      for (const card of cards) {
        if (!card.title || typeof card.title !== "string" || card.title.trim().length === 0) {
          return res.status(400).json({ error: `Each card must have a non-empty title. Invalid card found.` });
        }
        if (card.type && !VALID_TYPES.includes(card.type)) {
          return res.status(400).json({ error: `Invalid card type "${card.type}". Must be one of: ${VALID_TYPES.join(", ")}` });
        }
        if (card.status && !VALID_STATUSES.includes(card.status)) {
          return res.status(400).json({ error: `Invalid card status "${card.status}". Must be one of: ${VALID_STATUSES.join(", ")}` });
        }
        if (card.priority && !VALID_PRIORITIES.includes(card.priority)) {
          return res.status(400).json({ error: `Invalid card priority "${card.priority}". Must be one of: ${VALID_PRIORITIES.join(", ")}` });
        }
      }

      const results = [];

      for (const card of cards) {
        try {
          const existing = await db.query(
            "SELECT id FROM kanban_cards WHERE title = $1 AND app_target = $2",
            [card.title, card.app_target || "metric-market"]
          );

          let cardId;
          let operation;

          if (existing.rows.length > 0) {
            cardId = existing.rows[0].id;
            await db.query(`
              UPDATE kanban_cards SET
                type = COALESCE($1, type),
                status = COALESCE($2, status),
                priority = COALESCE($3, priority),
                description = COALESCE($4, description),
                acceptance_criteria = COALESCE($5, acceptance_criteria),
                technical_notes = COALESCE($6, technical_notes),
                estimated_effort = COALESCE($7, estimated_effort),
                assigned_to = COALESCE($8, assigned_to),
                dependencies = COALESCE($9, dependencies),
                tags = COALESCE($10, tags),
                agent_notes = COALESCE($11, agent_notes),
                updated_at = NOW()
              WHERE id = $12
            `, [
              card.type,
              card.status,
              card.priority,
              card.description,
              card.acceptance_criteria ? JSON.stringify(card.acceptance_criteria) : null,
              card.technical_notes,
              card.estimated_effort,
              card.assigned_to,
              card.dependencies ? JSON.stringify(card.dependencies) : null,
              card.tags ? JSON.stringify(card.tags) : null,
              card.agent_notes,
              cardId
            ]);
            operation = "updated";
          } else {
            const result = await db.query(`
              INSERT INTO kanban_cards (
                title, type, app_target, status, priority, description,
                acceptance_criteria, technical_notes, estimated_effort,
                assigned_to, dependencies, tags, agent_notes, position
              ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
                (SELECT COALESCE(MAX(position), 0) + 1 FROM kanban_cards WHERE status = $4))
              RETURNING id
            `, [
              card.title,
              card.type || "task",
              card.app_target || "metric-market",
              card.status || "backlog",
              card.priority || "medium",
              card.description,
              JSON.stringify(card.acceptance_criteria || []),
              card.technical_notes,
              card.estimated_effort,
              card.assigned_to,
              JSON.stringify(card.dependencies || []),
              JSON.stringify(card.tags || []),
              card.agent_notes
            ]);
            cardId = result.rows[0].id;
            operation = "created";
          }

          results.push({ card_id: cardId, title: card.title, operation });
        } catch (error) {
          results.push({ title: card.title, operation: "failed", error: error.message });
        }
      }

      console.log(`[Card Receiver] ${metadata?.source || "Unknown"} deployed ${cards.length} card(s)`);

      res.json({
        success: true,
        cards_processed: results.length,
        results,
        metadata
      });
    } catch (error) {
      console.error("[Card Receiver Error]", error);
      res.status(500).json({ error: "Card receiver failed", message: error.message });
    }
  });
};
