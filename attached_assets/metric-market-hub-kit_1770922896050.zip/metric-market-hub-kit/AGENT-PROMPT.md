# Hub Sync — Universal Agent Instructions
# Application: Metric Market (metric-market)
# Hub: http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev

You are working on "Metric Market", a spoke application in the People Analytics Toolbox ecosystem. The hub at http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev coordinates all spoke apps through directives, documentation scoring, and shared architecture.

## YOUR MISSION

Run the full hub sync cycle:
1. Fetch and process all pending directives from the hub
2. Execute the requested changes in this codebase
3. Refresh and improve the documentation (replit.md)
4. Push updated documentation back to the hub
5. Report directive completion back to the hub

## CURRENT STATUS

- Documentation Score: 63/100 (target: 80+)
- Pending Directives: 0
- Webhook Configured: No
- Documentation Pushed: Not yet

### Weak Documentation Sections
- **System Health & Recommendations**: 40/100
- **Features & Pages**: 65/100
- **Application Overview**: 60/100
- **Technology Stack**: 40/100
- **Current Instance Data Summary**: 40/100
- **Data Contracts & Export Formats**: 40/100

## STEP-BY-STEP PROCEDURE

### Step 1: Install the Hub SDK
Download the unified Hub SDK into your project root. This single file handles ALL hub communication:

```bash
curl -o hub-sdk.js "http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/sdk/metric-market"
```

Then set the `HUB_API_KEY` environment variable in your Replit Secrets tab. Find your API key at: http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/registry (click your app, then Integration tab).

If your app uses Express, add these two lines to your app entry point to register health, webhook, and specification endpoints automatically:

```javascript
const hubSdk = require("./hub-sdk");
hubSdk.init(app); // registers GET /health, POST /api/hub-webhook, GET /api/specifications
```

### Step 2: Fetch pending directives
Run this command to see what the hub is asking for:

```bash
node -e "
process.env.HUB_API_KEY = process.env.HUB_API_KEY || 'YOUR_API_KEY';
const sdk = require('./hub-sdk');
sdk.fetchDirectives().then(d => {
  const active = d.filter(x => x.status !== 'completed' && x.status !== 'rejected');
  console.log(JSON.stringify(active, null, 2));
}).catch(e => console.error(e.message));
"
```

### Step 3: Process each directive
For each pending/acknowledged directive, read its type and description, then act:

**For `doc_upgrade_request` directives:**
1. Read the directive description — it lists exactly which sections need improvement
2. Read your current `replit.md`
3. Add or expand the missing/weak sections following the scoring criteria below
4. Each section must have: 50+ words, bullet lists or tables, code snippets or technical terms
5. Use the EXACT heading formats listed in the Documentation Sections guide below

**For `requirement` directives:**
1. Read the description for what's being asked
2. Implement the required change in the codebase
3. Test that it works
4. Update replit.md if the change affects documentation

**For `instruction` directives:**
1. Follow the instructions in the description
2. These are typically configuration or integration tasks
3. Implement and test

### Step 4: Refresh documentation (replit.md)
After processing directives, ensure your `replit.md` covers ALL 9 required sections. The hub scores each section 0-100 using this rubric:

**Scoring Criteria (per section):**
- 20 points: Section exists with a matching heading
- Up to 40 points: Word count (50+ words = full marks, 20+ = partial)
- 20 points: Contains bullet lists, numbered lists, or tables
- 20 points: Contains code snippets (```), inline code, or technical terms (type/interface/schema/table/column)

**Required Documentation Sections:**
- **Application Overview** (key: `overview`): Purpose, core capabilities, key value proposition
- **Technology Stack** (key: `tech_stack`): Frontend, backend, infrastructure, AI integration
- **Platform Ecosystem Context** (key: `ecosystem`): Position in architecture, connected apps, data contracts, integration patterns
- **Features & Pages** (key: `features`): Every page with purpose, features, current state
- **Complete API Reference** (key: `api_reference`): Every endpoint with method, path, purpose, request/response
- **Database Schema** (key: `database`): Every table with columns, types, relationships
- **Data Contracts & Export Formats** (key: `data_contracts`): Any data formats the app produces/consumes
- **Current Instance Data Summary** (key: `instance_data`): What data currently exists
- **System Health & Recommendations** (key: `health`): Readiness metrics, validation warnings

**Heading Format:**
Use H2 headings (`## Section Title`) that match the patterns the scorer looks for. Safe heading formats:
- `## Application Overview` or `## Overview`
- `## Technology Stack` or `## Tech Stack`
- `## Platform Ecosystem Context` or `## Ecosystem Integration`
- `## Features & Pages` or `## Key Features`
- `## API Reference` or `## API Endpoints`
- `## Database Schema` or `## Data Model`
- `## Data Contracts & Export Formats`
- `## Current Instance Data Summary` or `## Instance Data`
- `## System Health & Recommendations` or `## Health & Status`

### Step 5: Push documentation to hub
After updating replit.md, push it using the SDK (which has built-in reversion protection):

```bash
node -e "
const sdk = require('./hub-sdk');
sdk.syncDocumentation().then(r => {
  if (r && !r.skipped) {
    console.log('New score:', r.score, '/ 100');
    console.log('Section scores:', JSON.stringify(r.sections, null, 2));
  } else if (r && r.skipped) {
    console.log('Skipped: documentation unchanged');
  }
}).catch(e => console.error(e.message));
"
```

The SDK automatically prevents documentation reversion — if the new content would significantly lower the quality score, the hub will reject it and tell you what's missing.

### Step 6: Mark directives complete
For each directive you processed, report completion:

```bash
node -e "
const sdk = require('./hub-sdk');
sdk.updateDirective(DIRECTIVE_ID, 'completed', 'SUMMARY_OF_WHAT_YOU_DID').then(r => console.log('Updated:', r)).catch(e => console.error(e.message));
"
```

Replace `DIRECTIVE_ID` with the actual ID and `SUMMARY_OF_WHAT_YOU_DID` with a brief description.

## AUTOMATED ALTERNATIVE

Instead of manual steps, you can run the full sync cycle with one command:

```bash
node -e "const sdk = require('./hub-sdk'); sdk.runFullSync().then(r => console.log('Results:', JSON.stringify(r, null, 2)));"
```

This fetches directives, processes doc upgrades, pushes documentation, and reports completion — all with reversion protection built in.

## IMPORTANT RULES

1. NEVER fabricate or hallucinate documentation content. Base everything on what actually exists in this codebase.
2. When adding documentation sections, introspect the actual code — read route files, schema files, package.json, and existing features.
3. Always push documentation AFTER making changes, not before.
4. Always mark directives as completed with a descriptive response after you've done the work.
5. If a directive asks for something you cannot do (e.g., major feature requiring human design decisions), mark it as acknowledged with an explanation, not completed.
