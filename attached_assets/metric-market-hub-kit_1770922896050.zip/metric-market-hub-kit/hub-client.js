// hub-client.js — Standard Hub Integration Module (LEGACY — prefer hub-sdk.js)
// Application: Metric Market (metric-market)
// Generated: 2026-02-12
//
// SETUP: Drop this file into your project root.
// All spoke apps MUST use this identical interface for consistency.

const HUB_URL = "http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev";
const APP_SLUG = "metric-market";
const API_KEY = "YOUR_API_KEY"; // Replace with key from Hub registry

const headers = {
  "Content-Type": "application/json",
  "X-API-Key": API_KEY,
};

// ── Core API Methods ──────────────────────────────────────────

async function fetchDirectives(status) {
  const url = status
    ? `${HUB_URL}/api/hub/app/${APP_SLUG}/directives?status=${status}`
    : `${HUB_URL}/api/hub/app/${APP_SLUG}/directives`;
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`Hub responded ${res.status}`);
  return res.json();
}

async function updateDirective(directiveId, status, response) {
  const body = { status };
  if (response) body.response = response;
  const res = await fetch(
    `${HUB_URL}/api/hub/app/${APP_SLUG}/directives/${directiveId}`,
    { method: "PATCH", headers, body: JSON.stringify(body) }
  );
  if (!res.ok) throw new Error(`Hub responded ${res.status}`);
  return res.json();
}

async function pushDocumentation(content, version) {
  const res = await fetch(
    `${HUB_URL}/api/hub/app/${APP_SLUG}/documentation`,
    { method: "POST", headers, body: JSON.stringify({ content, version }) }
  );
  if (!res.ok) throw new Error(`Hub responded ${res.status}`);
  return res.json();
}

async function fetchRegistry() {
  const res = await fetch(`${HUB_URL}/api/hub/registry`);
  if (!res.ok) throw new Error(`Hub responded ${res.status}`);
  return res.json();
}

async function fetchArchitecture() {
  const res = await fetch(`${HUB_URL}/api/hub/architecture`);
  if (!res.ok) throw new Error(`Hub responded ${res.status}`);
  return res.json();
}

// ── Lifecycle Helpers ─────────────────────────────────────────

async function acknowledgeDirective(directiveId) {
  return updateDirective(directiveId, "acknowledged");
}

async function completeDirective(directiveId, response) {
  return updateDirective(directiveId, "completed", response);
}

async function rejectDirective(directiveId, reason) {
  return updateDirective(directiveId, "rejected", reason);
}

// ── Auto-Polling (optional) ──────────────────────────────────

let pollTimer = null;

function startPolling(callback, intervalMs = 300000) {
  async function poll() {
    try {
      const directives = await fetchDirectives("pending");
      if (directives.length > 0) {
        for (const d of directives) {
          await acknowledgeDirective(d.id);
        }
        callback(directives);
      }
    } catch (err) {
      console.error("[hub-client] Poll error:", err.message);
    }
  }
  poll();
  pollTimer = setInterval(poll, intervalMs);
  return () => clearInterval(pollTimer);
}

function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
}

module.exports = {
  fetchDirectives,
  updateDirective,
  pushDocumentation,
  fetchRegistry,
  fetchArchitecture,
  acknowledgeDirective,
  completeDirective,
  rejectDirective,
  startPolling,
  stopPolling,
  HUB_URL,
  APP_SLUG,
};
