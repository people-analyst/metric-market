# Hub SDK v2.0.0 — Unified Communication Module

## Quick Start

```javascript
// 1. Drop hub-sdk.js into your project root
// 2. Set the HUB_API_KEY environment variable in Replit Secrets
// 3. Add these two lines to your Express app entry point:

const hubSdk = require("./hub-sdk");
hubSdk.init(app); // app = your Express instance
```

That's it. This single file replaces hub-client.js, hub-webhook.js, directive-executor.js, and hub-sync-agent.js.

## What It Does

On `init(app)`, the SDK automatically:
- Registers `GET /health` — Hub monitors your app's availability
- Registers `POST /api/hub-webhook` — Receives real-time directive notifications
- Registers `GET /api/specifications` — Serves your replit.md for documentation scoring
- Starts polling for pending directives every 5 minutes
- Checks for SDK updates from the Hub

## Environment Variable

Set `HUB_API_KEY` in your Replit Secrets tab. Find your API key at:
http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/registry → Click your app → Integration tab

## API Methods

```javascript
const hubSdk = require("./hub-sdk");

// Directives
await hubSdk.fetchDirectives("pending");
await hubSdk.updateDirective(id, "completed", "Done!");

// Documentation (with reversion protection built in)
await hubSdk.pushDocumentation(markdownContent, "v1.2");
await hubSdk.syncDocumentation(); // reads replit.md and pushes

// Full sync cycle (directives + docs in one call)
await hubSdk.runFullSync();

// Field Exchange
await hubSdk.getFieldManifest();
await hubSdk.exchangeFields(["emp_id", "hire_date"], []);

// Custom directive handler
hubSdk.init(app, {
  onDirective: async (directive) => {
    // Your custom logic here
    return "Completed: " + directive.title;
  }
});
```

## Checking for Updates

```javascript
const update = await hubSdk.checkSdkUpdate();
if (update?.updateAvailable) {
  console.log("New SDK version:", update.latest);
  // Download from: http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/sdk/metric-market
}
```

## Documentation Reversion Protection

The SDK prevents accidental documentation downgrades:
- Tracks content hashes to skip duplicate pushes
- Hub rejects pushes that would significantly lower your quality score
- Always uses monotonically increasing version timestamps

## Version

Current: v2.0.0
Check latest: GET http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/sdk/version
Download latest: GET http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/sdk/metric-market
