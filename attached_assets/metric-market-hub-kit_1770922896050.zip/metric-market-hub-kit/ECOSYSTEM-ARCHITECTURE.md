# People Analytics Toolbox — Ecosystem Architecture Guide

Generated: 2026-02-12 | Kit Version: 2026-02-12-mljtre99
Hub URL: http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev
Target Application: Metric Market (metric-market)

---

## 1. Ecosystem Overview

The People Analytics Toolbox is a hub-and-spoke architecture where a central Hub application monitors, documents, and coordinates a suite of spoke applications. Each spoke integrates with the Hub and the shared Product Kanban board for centralized development tracking.

### Registered Applications

| Name | Slug | Status | URL | Description |
|------|------|--------|-----|-------------|
| AnyComp | `anycomp` | online | https://compensation-hub.replit.app | Compensation Decision Support System — converts executive priorities and budget constraints into optimized compensation scenarios with VOI analysis. Consumes Meta-Factory microservices for job matching, pay ranges, and compensation modeling. |
| Conductor | `conductor` | online | https://data-model-explorer.replit.app | Data Intelligence Platform. Orchestrates data model exploration, people analytics, and cross-system integration. |
| Data Anonymizer | `data-anonymizer` | online | https://data-vault-anonymizer.replit.app | Data anonymization and privacy protection tool for People Analytics datasets. Handles PII detection, masking, tokenization, and synthetic data generation to ensure compliance with data privacy regulations. |
| Decision Wizard | `decision-wizard` | online | https://asset-manager-the1mikewest.replit.app | Decision support tool for People Analytics. Experimental standalone application guiding users through structured decision-making frameworks. |
| Metric Engine Calculus | `metric-engine-calculus` | online | https://metric-engine.replit.app | Computation engine for People Analytics metrics. Syncs metric definitions from the hub, calculates results, and performs statistical enrichment and trend analysis. |
| Metric Market | `metric-market` | unknown | https://metric-market.replit.app | Metrics Market is a data visualization and dashboard application that sits in the People Analytics Toolbox.
 People Analytics Toolbox is a hub-and-spoke platform for building, configuring, and displaying data visualization cards for People Analytics (HR/compensation/workforce metrics). 

The Metric Market serves two audiences:

Workbench (Admin side): Where superusers and AI agents author reusable "card bundles" — self-contained chart definitions that declare what data they need, how they're configured, and how they render. You can define metrics (like attrition rate, headcount), pair them with one of 20 chart types (multi-line, heatmap, bump chart, etc.), and assemble cards that track refresh status and scoring (importance, significance, relevance). Cards can be linked together for drill-down navigation.

Dashboard (Consumer side): Where end users view polished, pre-built cards fed by data from external "spoke" applications (like a Metric Calculator). It's a read-only experience showing the cards assembled in the workbench.

The whole system is API-driven (24 endpoints) so spoke apps can discover available bundles, push data payloads, and query cards programmatically. |
| PeopleAnalyst | `people-analyst` | online | https://performix.replit.app | Executive Forecasting & Decision Platform. Probabilistic forecasting, Monte Carlo simulation, VOI analysis. |
| Preference Modeler | `preference-modeler` | online | https://preference-modeler.replit.app | Preference & Survey Collection. Survey response collection and preference modeling. |
| Product Kanban | `kanban` | online | https://people-analytics-kanban.replit.app | Central development tracker for all PA Toolbox applications. Manages projects, features, tasks, and bugs across the ecosystem. |
| Reincarnation | `reincarnation` | online | https://reincarnation-engine.replit.app | Adaptive Diagnostic System. Survey item management with population-level learning and psychometric optimization. |
| Segmentation Studio | `segmentation-studio` | online | https://segmentation-builder.replit.app | Employee Segmentation Engine. HRIS normalization, canonical field mapping, dimension building, pack publishing. |
| VOI Calculator | `voi-calculator` | online | https://value-of-information.replit.app | Value of Investment calculator for People Analytics initiatives. Experimental standalone tool for quantifying ROI and business impact of analytics projects. |

### Architecture Principles
- **Hub is the registry of truth** for app metadata, documentation quality, and directives
- **Kanban is the work tracker of truth** for development cards — no local duplication
- **Spoke apps are autonomous** — they run independently but report status to the Hub
- **Communication is bi-directional** — Hub pushes directives, spokes push docs and status updates
- **AI agents are embedded** — both Hub and spokes can have Claude-powered agents with configurable capabilities

---

## 2. Hub API Reference — Complete Endpoint Catalog

### 2.1 Spoke-Facing Endpoints (Your App Calls These)

These endpoints are what your application uses to communicate with the Hub.

#### Authentication
All authenticated endpoints require the `X-API-Key` header with your app's API key.
Keys are auto-generated in `pat_...` format when you register your app.
Store your key in an environment variable — never commit it to source code.

```javascript
const headers = {
  "Content-Type": "application/json",
  "X-API-Key": process.env.HUB_API_KEY  // pat_... format
};
```

#### Directive Endpoints (Authenticated)

**GET /api/hub/app/:slug/directives**
Fetch directives assigned to your app. Supports `?status=pending` filter.

```javascript
// Example response
[
  {
    "id": 1,
    "title": "Implement data export feature",
    "description": "Add CSV/JSON export for all datasets",
    "type": "requirement",        // requirement | instruction | doc_upgrade_request
    "priority": "high",           // low | medium | high | critical
    "status": "pending",          // pending | acknowledged | in_progress | completed | rejected
    "appId": 3,
    "createdAt": "2025-01-15T10:00:00Z"
  }
]
```

**PATCH /api/hub/app/:slug/directives/:id**
Update a directive's status. Send the new status and optional response message.

```javascript
// Request body
{
  "status": "completed",          // acknowledged | in_progress | completed | rejected
  "response": "Export feature implemented in v2.1. Supports CSV and JSON formats."
}
```

**POST /api/hub/app/:slug/documentation**
Push your documentation content to the Hub for quality scoring.

```javascript
// Request body
{
  "content": "# My App\n## Overview\n...",  // Full markdown content
  "version": "1.0.0"                          // Optional version tag
}
```

#### Field Exchange Endpoints (Authenticated)

**GET /api/hub/app/:slug/fields/manifest**
Lightweight version check — returns field count, alias count, and last update timestamp.

```javascript
// Example response
{
  "version": "2025-01-15T10:00:00.000Z",
  "totalFields": 66,
  "totalAliases": 385,
  "categories": ["identification", "demographics", "employment", ...],
  "lastUpdated": "2025-01-15T10:00:00.000Z"
}
```

**POST /api/hub/app/:slug/fields/exchange**
Bulk sync: send discovered column names + confirmed mappings, get matches back.

```javascript
// Request body
{
  "discoveredNames": ["EmpID", "HireDate", "BasePay"],
  "confirmedMappings": [
    { "sourceName": "EmpID", "canonicalFieldName": "employee_id" }
  ],
  "sourceType": "workday"
}
// Returns: matches, created mappings, enriched aliases, unmatched names
```

**POST /api/hub/app/:slug/fields/match**
Quick-match column names without creating mappings (preview mode).

```javascript
// Request body
{ "names": ["EmpID", "HireDate", "BasePay"] }
// Returns: array of { inputName, matches: [{ field, confidence, matchType }] }
```

**GET /api/sdk/field-exchange-client.ts**
Download the zero-dependency TypeScript SDK for field exchange integration.

#### Public Endpoints (No Auth Required)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/hub/registry` | GET | Full list of all registered apps with metadata |
| `/api/hub/architecture` | GET | Compiled ecosystem architecture document |
| `/api/hub/app/:slug` | GET | Single app's documentation and metadata |
| `/api/fields` | GET | Full canonical field library (66 fields, 385+ aliases) |

### 2.2 Endpoints Your App Must Expose

The Hub calls these endpoints on your application:

| Endpoint | Method | Purpose | Required |
|----------|--------|---------|----------|
| `/health` | GET | Health check — Hub monitors availability | Yes |
| `/api/hub-webhook` | POST | Receives real-time directive notifications | Yes |
| `/api/specifications` | GET | Hub pulls your documentation for scoring | Yes |

**Health endpoint response format:**
```json
{
  "status": "ok",
  "app": "metric-market",
  "timestamp": "2025-01-15T10:00:00.000Z"
}
```

**Webhook payload format (what the Hub sends):**
```json
{
  "event": "directive.created",
  "directive": {
    "id": 1,
    "title": "Implement feature X",
    "type": "requirement",
    "priority": "high",
    "description": "..."
  },
  "app": {
    "id": 3,
    "name": "Metric Market",
    "slug": "metric-market"
  }
}
```

---

## 3. Kanban API Reference — Product Development Board

The Product Kanban at `https://people-analytics-kanban.replit.app` is the shared development tracker for all ecosystem applications. The Hub also proxies these at `http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/kanban/*`.

### Direct Kanban Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `GET /api/kanban/cards` | GET | List all cards. Filters: `?app=`, `?status=`, `?priority=`, `?type=` |
| `GET /api/kanban/cards/:id` | GET | Get single card details |
| `POST /api/kanban/cards` | POST | Create a new development card |
| `PATCH /api/kanban/cards/:id` | PATCH | Update card status, priority, or details |
| `GET /api/kanban/hub/status` | GET | Board summary with counts by status |

### Card Schema

```javascript
// Creating a card
{
  "title": "Implement data anonymization",   // Required
  "description": "Add PII redaction...",      // Optional
  "type": "feature",                          // project | feature | task | bug
  "status": "backlog",                        // backlog | planned | in_progress | review | done
  "priority": "high",                         // critical | high | medium | low
  "appTarget": "metric-market"                      // Your app slug — links card to your app
}
```

### Fetching Your App's Cards

```javascript
// Get all cards assigned to your app
const cards = await fetch("https://people-analytics-kanban.replit.app/api/kanban/cards?app=metric-market");

// Get only in-progress work
const active = await fetch("https://people-analytics-kanban.replit.app/api/kanban/cards?app=metric-market&status=in_progress");
```

---

## 4. Communication Protocols

### Hub → Spoke (Outbound)

1. **Directives** — Hub creates requirements, instructions, or doc upgrade requests targeting specific apps
2. **Webhooks** — Hub pushes real-time notifications to spoke apps when directives are created
3. **Health checks** — Hub periodically pings spoke `/health` endpoints to monitor availability
4. **Card deployment** — Hub (or AI agent) pushes Kanban cards to spoke apps via `POST /api/receive-cards`

### Spoke → Hub (Inbound)

1. **Poll directives** — Spoke calls `GET /api/hub/app/:slug/directives?status=pending`
2. **Update status** — Spoke calls `PATCH /api/hub/app/:slug/directives/:id` to acknowledge/complete/reject
3. **Push documentation** — Spoke calls `POST /api/hub/app/:slug/documentation` to push docs
4. **Deploy cards** — Spoke calls `POST http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/kanban/deploy-cards` to push cards to the Kanban board

### Card Deployment Protocol

The Hub AI agent and spoke apps can push development cards to each other and to the central Kanban board. This enables AI-driven project management across the ecosystem.

**Hub/Agent → Kanban** (via Hub endpoint):
\`\`\`javascript
// Hub pushes cards to Kanban via deploy-cards endpoint
POST http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev/api/kanban/deploy-cards
Authorization: Bearer ${DEPLOY_SECRET}
Body: { cards: [...], metadata: { source: "app-slug" } }
\`\`\`

**Hub/Agent → Spoke** (via receive-cards endpoint):
\`\`\`javascript
// Hub pushes cards directly to a spoke app's local database
POST https://your-spoke-app.replit.app/api/receive-cards
Authorization: Bearer ${DEPLOY_SECRET}
Body: { cards: [...], metadata: { source: "hub-toolbox" } }
\`\`\`

**Security**: All card deployment endpoints require the shared `DEPLOY_SECRET` in the Authorization header. Set this as a Replit Secret in every app that participates in card deployment.

### Directive Lifecycle

```
pending → acknowledged → in_progress → completed
                                     → rejected
```

1. Hub creates directive (status: pending)
2. Spoke receives via webhook or polling
3. Spoke acknowledges (status: acknowledged)
4. Spoke begins work (status: in_progress)
5. Spoke completes or rejects with response message

---

## 5. Documentation Quality System

The Hub scores documentation across 9 sections. Each section is scored 0-100:

| Points | Criteria |
|--------|----------|
| 20 | Section heading present |
| Up to 40 | Word count (10pts for 5+ words, 25pts for 20+, 40pts for 50+) |
| 20 | Contains lists or tables |
| 20 | Contains code blocks or schema definitions |

### Required Sections

- **Application Overview** — Purpose, core capabilities, key value proposition
- **Technology Stack** — Frontend, backend, infrastructure, AI integration
- **Platform Ecosystem Context** — Position in architecture, connected apps, data contracts, integration patterns
- **Features & Pages** — Every page with purpose, features, current state
- **Complete API Reference** — Every endpoint with method, path, purpose, request/response
- **Database Schema** — Every table with columns, types, relationships
- **Data Contracts & Export Formats** — Any data formats the app produces/consumes
- **Current Instance Data Summary** — What data currently exists
- **System Health & Recommendations** — Readiness metrics, validation warnings

---

## 6. Authentication Details

### API Key Management
- Keys are auto-generated in `pat_` + 32 hex chars format
- Store in environment variables, never in source code
- Keys can be regenerated from the Hub UI (Integration tab on your app's detail page)
- Regeneration invalidates the old key immediately

### Authenticating Requests
```javascript
const response = await fetch(`${HUB_URL}/api/hub/app/${APP_SLUG}/directives`, {
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": process.env.HUB_API_KEY
  }
});
```

---

## 7. File Inventory

This dev kit includes the following files:

| File | Purpose | Replace on Update? |
|------|---------|-------------------|
| `hub-client.js` | Core Hub API client — all methods for directives, docs, registry | Yes — always use latest |
| `hub-webhook.js` | Express routes for health, webhook, and specs endpoints | Yes — always use latest |
| `kanban-client.js` | Kanban board API client — create, update, fetch, deploy cards | Yes — always use latest |
| `receive-cards.js` | Card receiver endpoint — accepts card pushes from Hub/Agent | Yes — always use latest |
| `directive-executor.js` | Optional AI-powered directive processing with Claude | Yes — always use latest |
| `hub-config.json` | Configuration with all endpoints, scoring criteria, lifecycle | Yes — always use latest |
| `DOCUMENTATION-TEMPLATE.md` | Markdown template matching hub scoring criteria | No — fill in once, keep your content |
| `ECOSYSTEM-ARCHITECTURE.md` | This file — complete API and architecture reference | Reference only |
| `AGENT-VISION.md` | Developer agent design and role system guide | Reference only |
| `README.md` | Setup and integration guide | Reference only |

### Feature Modules (optional, self-contained)

| Module | Files | Purpose |
|--------|-------|---------|
| Documentation | `feature-modules/documentation/*` | Self-documentation scoring against hub's 9-section framework |
| Dev Context Generator | `feature-modules/context-generator/*` | Auto-introspect codebase for AI agent context |
| Field Exchange | `feature-modules/field-exchange/*` | Canonical field library integration with SDK, routes, and UI |

---

_Generated by People Analytics Toolbox Hub on 2026-02-12_
