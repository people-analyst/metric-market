// kanban-client.js — Product Kanban Integration Module
// Application: Metric Market (metric-market)
// Generated: 2026-02-12
//
// Provides methods to interact with the Product Kanban board
// for development tracking across the PA Toolbox ecosystem.
// Includes both read operations (fetch cards) and write operations
// (create, update, deploy cards via Hub).

const KANBAN_BASE = "https://people-analytics-kanban.replit.app";
const HUB_URL = "http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev";

async function fetchCards(filters = {}) {
  const params = new URLSearchParams();
  if (filters.app) params.set("app", filters.app);
  if (filters.status) params.set("status", filters.status);
  if (filters.priority) params.set("priority", filters.priority);
  if (filters.type) params.set("type", filters.type);
  const qs = params.toString();
  const res = await fetch(`${KANBAN_BASE}/api/kanban/cards${qs ? "?" + qs : ""}`);
  if (!res.ok) throw new Error(`Kanban fetch failed: ${res.status}`);
  return res.json();
}

async function fetchMyCards(status) {
  return fetchCards({ app: "metric-market", ...(status ? { status } : {}) });
}

async function createCard(card) {
  const res = await fetch(`${KANBAN_BASE}/api/kanban/cards`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ appTarget: "metric-market", ...card }),
  });
  if (!res.ok) throw new Error(`Card creation failed: ${res.status}`);
  return res.json();
}

async function updateCard(cardId, updates) {
  const res = await fetch(`${KANBAN_BASE}/api/kanban/cards/${cardId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updates),
  });
  if (!res.ok) throw new Error(`Card update failed: ${res.status}`);
  return res.json();
}

async function getBoardStatus() {
  const res = await fetch(`${KANBAN_BASE}/api/kanban/hub/status`);
  if (!res.ok) throw new Error(`Status check failed: ${res.status}`);
  return res.json();
}

async function deployCards(cards, metadata = {}) {
  const DEPLOY_SECRET = process.env.DEPLOY_SECRET;
  if (!DEPLOY_SECRET) throw new Error("DEPLOY_SECRET not set in environment");
  const res = await fetch(`${HUB_URL}/api/kanban/deploy-cards`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${DEPLOY_SECRET}`,
    },
    body: JSON.stringify({
      cards: cards.map(c => ({ appTarget: c.appTarget || "metric-market", ...c })),
      metadata: { source: "metric-market", ...metadata },
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Card deployment failed (${res.status}): ${err}`);
  }
  return res.json();
}

module.exports = { fetchCards, fetchMyCards, createCard, updateCard, getBoardStatus, deployCards };
