# Documentation Feature Module
## Application: Metric Market | Generated: 2026-02-12

This module provides a **complete self-documentation system** that scores your
app's own \`replit.md\` against the same 9-section quality framework used by
the Platform Hub. It includes backend routes, a scoring engine, and a React
page component.

## Files

| File | Purpose | Destination |
|------|---------|-------------|
| \`doc-scorer.js\` | Quality scoring engine (9 sections, 0-100 per section) | Project root or \`server/\` |
| \`doc-routes.js\` | Express API routes (\`/api/self-docs\`, \`/api/self-docs/export\`) | Project root or \`server/\` |
| \`SelfDocumentation.tsx\` | React page with quality breakdown + rendered docs | \`client/src/pages/\` |

## Quick Setup

### 1. Backend Routes
\`\`\`javascript
// In your Express server setup (e.g., server/routes.ts or server/index.ts):
const { registerDocRoutes } = require("./feature-modules/documentation/doc-routes");
registerDocRoutes(app);
\`\`\`

### 2. Frontend Route
\`\`\`tsx
// In your App.tsx router:
import SelfDocumentation from "@/pages/self-documentation";

<Route path="/documentation" component={SelfDocumentation} />
\`\`\`

### 3. Sidebar Navigation
\`\`\`tsx
// Add to your sidebar nav items:
{ title: "Docs", url: "/documentation", icon: FileText }
\`\`\`

### 4. Dependencies
Ensure these packages are installed (they are standard in the ecosystem):
- \`react-markdown\`
- \`remark-gfm\`
- \`date-fns\`

## How It Works

1. Backend reads the app's \`replit.md\` file from disk
2. Scoring engine evaluates 9 required sections (presence, word count, structure, code/schemas)
3. Frontend displays quality breakdown with progress bars + full rendered documentation
4. Export button lets users download the raw markdown

## Scoring Criteria (per section, 0-100)
- **20 pts**: Section is present with content
- **40 pts**: Substantive content (50+ words = full marks, 20+ words = partial)
- **20 pts**: Uses lists, tables, or structured data
- **20 pts**: Contains code snippets, schema definitions, or technical terms

## Consistency
This module uses the EXACT same scoring algorithm as the Platform Hub.
Your app's self-assessed score will match what the hub reports.
