// doc-scorer.ts — Documentation Quality Scoring Engine
// Feature Module: Documentation | Application: Metric Market
// Generated: 2026-02-12
// 
// Scores markdown documentation against 9 required sections.
// This is the SAME scoring engine used by the hub — ensuring consistency.

const REQUIRED_DOC_SECTIONS = [
  { key: "overview", title: "Application Overview", description: "Purpose, capabilities, value proposition" },
  { key: "tech_stack", title: "Technology Stack", description: "Frontend, backend, infrastructure details" },
  { key: "ecosystem", title: "Platform Ecosystem Context", description: "Position in People Analytics architecture" },
  { key: "features", title: "Features & Pages", description: "All pages/routes with purposes" },
  { key: "api_reference", title: "Complete API Reference", description: "Every endpoint with method, path, purpose" },
  { key: "database", title: "Database Schema", description: "Tables, columns, types, relationships" },
  { key: "data_contracts", title: "Data Contracts & Export Formats", description: "JSON schemas, CSV formats, data contracts" },
  { key: "instance_data", title: "Current Instance Data Summary", description: "What data currently exists" },
  { key: "health", title: "System Health & Recommendations", description: "Readiness metrics, known issues" },
];

const SECTION_HEADING_PATTERNS = {
  overview: [/^#+\s+.*overview/im, /^#+\s+.*purpose/im, /^#+\s+.*about\b/im, /^#+\s+.*introduction/im],
  tech_stack: [/^#+\s+.*tech\s*stack/im, /^#+\s+.*technology/im, /^#+\s+.*stack/im, /^#+\s+.*built\s+with/im],
  ecosystem: [/^#+\s+.*ecosystem/im, /^#+\s+.*integration/im, /^#+\s+.*platform/im, /^#+\s+.*hub/im, /^#+\s+.*architecture/im],
  features: [/^#+\s+.*features/im, /^#+\s+.*pages/im, /^#+\s+.*key\s+pages/im, /^#+\s+.*routes/im, /^#+\s+.*capabilities/im, /^#+\s+.*project\s+structure/im],
  api_reference: [/^#+\s+.*api\s+reference/im, /^#+\s+.*api\s+endpoints/im, /^#+\s+.*api\s+routes/im, /^#+\s+.*endpoints/im],
  database: [/^#+\s+.*database/im, /^#+\s+.*schema/im, /^#+\s+.*data\s+model/im, /^#+\s+.*tables/im, /^#+\s+.*models/im],
  data_contracts: [/^#+\s+.*data\s+contracts/im, /^#+\s+.*export/im, /^#+\s+.*data\s+formats/im, /^#+\s+.*payloads/im],
  instance_data: [/^#+\s+.*instance\s+data/im, /^#+\s+.*current\s+data/im, /^#+\s+.*data\s+summary/im, /^#+\s+.*seed\s+data/im, /^#+\s+.*pre.?registered/im],
  health: [/^#+\s+.*health/im, /^#+\s+.*status/im, /^#+\s+.*recommendations/im, /^#+\s+.*readiness/im, /^#+\s+.*known\s+issues/im],
};

function extractSectionContent(markdown, sectionKey) {
  const patterns = SECTION_HEADING_PATTERNS[sectionKey] || [];
  const lines = markdown.split("\n");
  for (const pattern of patterns) {
    let startIdx = -1;
    let endIdx = lines.length;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (startIdx === -1) {
        if (pattern.test(line)) {
          startIdx = i;
          const headingLevel = (line.match(/^#+/) || [""])[0].length;
          for (let j = i + 1; j < lines.length; j++) {
            const nextLine = lines[j].trim();
            if (nextLine.startsWith("#")) {
              const nextLevel = (nextLine.match(/^#+/) || [""])[0].length;
              if (nextLevel <= headingLevel) { endIdx = j; break; }
            }
          }
          break;
        }
      }
    }
    if (startIdx !== -1) {
      const content = lines.slice(startIdx + 1, endIdx).join("\n").trim();
      if (content.length > 10) return content;
    }
  }
  return null;
}

function scoreSection(content) {
  if (!content) return 0;
  let score = 20;
  const wordCount = content.split(/\s+/).length;
  if (wordCount > 50) score += 40;
  else if (wordCount > 20) score += 25;
  else if (wordCount > 5) score += 10;
  if (/^[-*]\s/m.test(content) || /^\d+\.\s/m.test(content) || /\|.*\|.*\|/m.test(content)) score += 20;
  if (/\`\`\`/.test(content) || /\`[^\`]+\`/.test(content) || /\b(type|interface|schema|table|column)\b/i.test(content)) score += 20;
  return Math.min(100, score);
}

function scoreDocumentation(markdown) {
  const sections = {};
  const parsedSections = {};
  for (const section of REQUIRED_DOC_SECTIONS) {
    const content = extractSectionContent(markdown, section.key);
    parsedSections[section.key] = content;
    sections[section.key] = scoreSection(content);
  }
  const scores = Object.values(sections);
  const overall = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  return { sections, overall, parsedSections, REQUIRED_DOC_SECTIONS };
}

module.exports = { scoreDocumentation, REQUIRED_DOC_SECTIONS };
