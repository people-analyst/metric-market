// doc-routes.js — Self-Documentation API Routes
// Feature Module: Documentation | Application: Metric Market
// Generated: 2026-02-12
//
// Add these routes to your Express app:
//   const { registerDocRoutes } = require("./feature-modules/documentation/doc-routes");
//   registerDocRoutes(app);

const fs = require("fs");
const path = require("path");
const { scoreDocumentation, REQUIRED_DOC_SECTIONS } = require("./doc-scorer");

function registerDocRoutes(app) {
  app.get("/api/self-docs", (req, res) => {
    try {
      const replitMdPath = path.resolve(process.cwd(), "replit.md");
      if (!fs.existsSync(replitMdPath)) {
        return res.status(404).json({ message: "replit.md not found" });
      }
      const rawContent = fs.readFileSync(replitMdPath, "utf-8");
      const { sections, overall, parsedSections } = scoreDocumentation(rawContent);
      const stat = fs.statSync(replitMdPath);
      res.json({
        rawContent,
        parsedSections,
        sections,
        overall,
        version: stat.mtime.toISOString(),
        lastModified: stat.mtime.toISOString(),
        requiredSections: REQUIRED_DOC_SECTIONS,
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/self-docs/export", (req, res) => {
    try {
      const replitMdPath = path.resolve(process.cwd(), "replit.md");
      if (!fs.existsSync(replitMdPath)) {
        return res.status(404).json({ message: "replit.md not found" });
      }
      const rawContent = fs.readFileSync(replitMdPath, "utf-8");
      res.setHeader("Content-Type", "text/markdown");
      res.setHeader("Content-Disposition", "attachment; filename=metric-market-documentation.md");
      res.send(rawContent);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
}

module.exports = { registerDocRoutes };
