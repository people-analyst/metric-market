// SelfDocumentation.tsx — Self-Documentation Page Component
// Feature Module: Documentation | Application: Metric Market
// Generated: 2026-02-12
//
// USAGE:
// 1. Copy this file to client/src/pages/self-documentation.tsx
// 2. Add route: <Route path="/documentation" component={SelfDocumentation} />
// 3. Add sidebar nav item: { title: "Docs", url: "/documentation", icon: FileText }
// 4. Install dependencies if not present: react-markdown, remark-gfm, date-fns
//
// This page reads the app's own replit.md, scores it against the hub's
// 9-section quality framework, and displays a quality breakdown + rendered docs.

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { FileText, Download, BookOpen, BarChart3 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { formatDistanceToNow } from "date-fns";

interface DocSection {
  key: string;
  title: string;
  description: string;
}

interface SelfDocs {
  rawContent: string;
  parsedSections: Record<string, string | null>;
  sections: Record<string, number>;
  overall: number;
  version: string;
  lastModified: string;
  requiredSections: DocSection[];
}

function QualityBadge({ score }: { score: number }) {
  let variant: "default" | "secondary" | "destructive" | "outline" = "destructive";
  if (score >= 80) variant = "default";
  else if (score >= 50) variant = "secondary";
  return <Badge variant={variant}>{score}%</Badge>;
}

function SectionScore({ section, score }: { section: DocSection; score: number }) {
  return (
    <div className="flex items-center gap-3 py-2" data-testid={\`section-score-\${section.key}\`}>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{section.title}</span>
          <span className="text-xs text-muted-foreground">{score}%</span>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">{section.description}</p>
      </div>
      <div className="w-24 flex-shrink-0">
        <Progress value={score} className="h-2" />
      </div>
    </div>
  );
}

export default function SelfDocumentation() {
  const { data: docs, isLoading } = useQuery<SelfDocs>({
    queryKey: ["/api/self-docs"],
  });

  if (isLoading) {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-96" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!docs) {
    return (
      <div className="p-6 max-w-5xl mx-auto">
        <p className="text-muted-foreground">Unable to load documentation.</p>
      </div>
    );
  }

  const requiredSections = docs.requiredSections || [];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
              Documentation
            </h1>
            <QualityBadge score={docs.overall} />
          </div>
          <p className="text-muted-foreground mt-1">
            Quality-scored documentation against ecosystem standards
          </p>
          {docs.lastModified && (
            <p className="text-xs text-muted-foreground mt-1">
              Last modified {formatDistanceToNow(new Date(docs.lastModified), { addSuffix: true })}
            </p>
          )}
        </div>
        <a href="/api/self-docs/export" download>
          <Button variant="outline" size="sm" data-testid="button-export-docs">
            <Download className="h-3.5 w-3.5 mr-1" />
            Export
          </Button>
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{docs.overall}%</p>
                <p className="text-xs text-muted-foreground">Overall Score</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <BookOpen className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {Object.values(docs.sections).filter(s => s > 0).length}/{requiredSections.length}
                </p>
                <p className="text-xs text-muted-foreground">Sections Covered</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <FileText className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {docs.rawContent ? docs.rawContent.split(/\s+/).length.toLocaleString() : 0}
                </p>
                <p className="text-xs text-muted-foreground">Total Words</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="quality" className="space-y-4">
        <TabsList>
          <TabsTrigger value="quality" data-testid="tab-quality">Quality</TabsTrigger>
          <TabsTrigger value="documentation" data-testid="tab-documentation">Full Docs</TabsTrigger>
        </TabsList>
        <TabsContent value="quality">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <CardTitle className="text-base">Section Scores</CardTitle>
              <Badge variant="secondary">{docs.overall}% overall</Badge>
            </CardHeader>
            <CardContent>
              <div className="divide-y">
                {requiredSections.map((section) => (
                  <SectionScore key={section.key} section={section} score={docs.sections[section.key] ?? 0} />
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="documentation">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="h-4 w-4" />
                replit.md
              </CardTitle>
            </CardHeader>
            <CardContent>
              {docs.rawContent ? (
                <div className="prose prose-sm dark:prose-invert max-w-none" data-testid="text-documentation-content">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {docs.rawContent}
                  </ReactMarkdown>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No documentation content available.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
