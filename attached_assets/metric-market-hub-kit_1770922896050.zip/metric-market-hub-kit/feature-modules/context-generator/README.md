# Dev Context Generator Feature Module
## Application: Metric Market | Generated: 2026-02-12

This module auto-introspects your codebase and generates rich development context
for embedded AI agents. It extracts tech stack info, code patterns, API routes,
database schema, file structure, environment variables, and recent git history.

## Files

| File | Purpose | Destination |
|------|---------|-------------|
| \`context-generator.js\` | Core analysis engine (tech stack, patterns, routes, schema) | Project root or \`server/\` |
| \`context-routes.js\` | Express API routes (\`/api/context\`, \`/api/context/generate\`, \`/api/context/export\`) | Project root or \`server/\` |
| \`DevContext.tsx\` | React page with tabbed view of generated context | \`client/src/pages/\` |

## Quick Setup

### 1. Backend Routes
\`\`\`javascript
// In your Express server setup:
const { registerContextRoutes } = require("./feature-modules/context-generator/context-routes");
registerContextRoutes(app);
\`\`\`

### 2. Frontend Route
\`\`\`tsx
// In your App.tsx router:
import DevContext from "@/pages/dev-context";

<Route path="/dev-context" component={DevContext} />
\`\`\`

### 3. Sidebar Navigation
\`\`\`tsx
// Add to your sidebar nav items:
{ title: "Dev Context", url: "/dev-context", icon: Code }
\`\`\`

### 4. Dependencies
Ensure these packages are installed:
- \`react-markdown\`
- \`remark-gfm\`

## How It Works

1. Analysis engine scans the project directory for source files
2. Extracts API routes from Express route definitions
3. Parses Drizzle/ORM schema definitions for database tables
4. Detects code patterns (async style, error handling, import style)
5. Reads package.json for dependency analysis
6. Runs \`git log\` for recent commit history
7. Results are cached in memory and regenerated on demand

## AI Agent Integration

Feed the generated context into your AI agent's system prompt:
\`\`\`javascript
const ctx = await fetch("/api/context").then(r => r.json());
// Include ctx.markdown in your agent's system prompt for codebase awareness
\`\`\`
