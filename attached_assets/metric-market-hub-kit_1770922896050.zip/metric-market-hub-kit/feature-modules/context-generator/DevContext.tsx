// DevContext.tsx — Development Context Page Component
// Feature Module: Dev Context Generator | Application: Metric Market
// Generated: 2026-02-12
//
// USAGE:
// 1. Copy this file to client/src/pages/dev-context.tsx
// 2. Add route: <Route path="/dev-context" component={DevContext} />
// 3. Add sidebar nav item: { title: "Dev Context", url: "/dev-context", icon: Code }

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Code, Download, RefreshCw, Database, Globe, GitCommit, FolderTree, Cpu } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export default function DevContext() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["/api/context"] });

  const regenerate = useMutation({
    mutationFn: () => fetch("/api/context/generate", { method: "POST" }).then(r => r.json()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/context"] }),
  });

  if (isLoading) {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-96" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const ctx = data?.data;
  if (!ctx) return <div className="p-6"><p className="text-muted-foreground">No context available.</p></div>;

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">Dev Context</h1>
          <p className="text-muted-foreground mt-1">Auto-generated development context for AI agents</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => regenerate.mutate()} disabled={regenerate.isPending} data-testid="button-regenerate">
            <RefreshCw className={\`h-3.5 w-3.5 mr-1 \${regenerate.isPending ? "animate-spin" : ""}\`} />
            Regenerate
          </Button>
          <a href="/api/context/export" download>
            <Button variant="outline" size="sm" data-testid="button-export">
              <Download className="h-3.5 w-3.5 mr-1" /> Export
            </Button>
          </a>
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="routes" data-testid="tab-routes">API Routes</TabsTrigger>
          <TabsTrigger value="schema" data-testid="tab-schema">Database</TabsTrigger>
          <TabsTrigger value="full" data-testid="tab-full">Full Context</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2">
                <CardTitle className="text-base flex items-center gap-2"><Cpu className="h-4 w-4" /> Tech Stack</CardTitle>
              </CardHeader>
              <CardContent>
                {Object.entries(ctx.techStack || {}).map(([k, v]) => (
                  <div key={k} className="flex justify-between py-1.5 border-b last:border-0">
                    <span className="text-sm text-muted-foreground capitalize">{k}</span>
                    <span className="text-sm font-medium">{v}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2">
                <CardTitle className="text-base flex items-center gap-2"><GitCommit className="h-4 w-4" /> Recent Changes</CardTitle>
              </CardHeader>
              <CardContent>
                {(ctx.recentCommits || []).slice(0, 5).map((c, i) => (
                  <div key={i} className="flex gap-2 py-1.5 border-b last:border-0">
                    <code className="text-xs text-muted-foreground shrink-0">{c.hash}</code>
                    <span className="text-sm truncate">{c.message}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="routes">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <CardTitle className="text-base flex items-center gap-2"><Globe className="h-4 w-4" /> API Routes</CardTitle>
              <Badge variant="secondary">{(ctx.apiRoutes || []).length} routes</Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {(ctx.apiRoutes || []).map((r, i) => (
                  <div key={i} className="flex items-center gap-3 py-1.5 border-b last:border-0">
                    <Badge variant="outline" className="font-mono text-xs w-16 justify-center">{r.method}</Badge>
                    <code className="text-sm">{r.path}</code>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="schema">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <CardTitle className="text-base flex items-center gap-2"><Database className="h-4 w-4" /> Database Tables</CardTitle>
              <Badge variant="secondary">{(ctx.dbSchema || []).length} tables</Badge>
            </CardHeader>
            <CardContent>
              {(ctx.dbSchema || []).map((t, i) => (
                <div key={i} className="flex items-center gap-3 py-1.5 border-b last:border-0">
                  <code className="text-sm font-medium">{t.tableName}</code>
                  <span className="text-xs text-muted-foreground">({t.varName})</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="full">
          <Card>
            <CardContent className="p-6">
              {data?.markdown ? (
                <div className="prose prose-sm dark:prose-invert max-w-none" data-testid="text-full-context">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{data.markdown}</ReactMarkdown>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No context generated yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
