// context-routes.js — Dev Context API Routes
// Feature Module: Dev Context Generator | Application: Metric Market
// Generated: 2026-02-12
//
// Add these routes to your Express app:
//   const { registerContextRoutes } = require("./feature-modules/context-generator/context-routes");
//   registerContextRoutes(app);

const { generateDevelopmentContext, formatContextAsMarkdown } = require("./context-generator");

let cachedCtx = null;

function registerContextRoutes(app) {
  app.get("/api/context", (req, res) => {
    try {
      if (!cachedCtx) {
        const data = generateDevelopmentContext("Metric Market");
        const markdown = formatContextAsMarkdown(data);
        cachedCtx = { data, markdown, generatedAt: new Date().toISOString() };
      }
      res.json(cachedCtx);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/context/generate", (req, res) => {
    try {
      const data = generateDevelopmentContext("Metric Market");
      const markdown = formatContextAsMarkdown(data);
      cachedCtx = { data, markdown, generatedAt: new Date().toISOString() };
      res.json(cachedCtx);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/context/export", (req, res) => {
    try {
      if (!cachedCtx) {
        const data = generateDevelopmentContext("Metric Market");
        const markdown = formatContextAsMarkdown(data);
        cachedCtx = { data, markdown, generatedAt: new Date().toISOString() };
      }
      res.setHeader("Content-Type", "text/markdown");
      res.setHeader("Content-Disposition", "attachment; filename=metric-market-dev-context.md");
      res.send(cachedCtx.markdown);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
}

module.exports = { registerContextRoutes };
