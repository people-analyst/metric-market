// context-generator.js — Development Context Generator
// Feature Module: Dev Context Generator | Application: Metric Market
// Generated: 2026-02-12
//
// Auto-introspects the codebase to produce rich development context:
// tech stack, dependencies, file structure, API routes, DB schema,
// code patterns, env vars, and recent git history.

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

function safeExec(cmd, fallback = "") {
  try {
    return execSync(cmd, { encoding: "utf-8", timeout: 5000, cwd: process.cwd() }).trim();
  } catch {
    return fallback;
  }
}

function detectTechStack() {
  const stack = { language: "unknown", runtime: "unknown", framework: "unknown", database: "unknown", frontend: "unknown", bundler: "unknown" };
  const pkgPath = path.resolve(process.cwd(), "package.json");
  if (!fs.existsSync(pkgPath)) return stack;
  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
  const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
  if (allDeps.typescript) stack.language = "TypeScript";
  else stack.language = "JavaScript";
  stack.runtime = "Node.js";
  if (allDeps.express) stack.framework = "Express.js";
  if (allDeps.drizzle || allDeps["drizzle-orm"]) stack.database = "PostgreSQL + Drizzle ORM";
  else if (allDeps.pg || allDeps["pg-pool"]) stack.database = "PostgreSQL";
  if (allDeps.react) stack.frontend = "React";
  if (allDeps.vite) stack.bundler = "Vite";
  return stack;
}

function getDependencies() {
  const pkgPath = path.resolve(process.cwd(), "package.json");
  if (!fs.existsSync(pkgPath)) return { production: {}, development: {} };
  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
  return { production: pkg.dependencies || {}, development: pkg.devDependencies || {} };
}

function getFileStructure(maxDepth = 3) {
  const result = safeExec(\`find . -maxdepth \${maxDepth} -type f \\( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \\) -not -path "*/node_modules/*" -not -path "*/.git/*" -not -path "*/dist/*" | sort\`);
  return result ? result.split("\n").filter(Boolean) : [];
}

function extractApiRoutes() {
  const routeFiles = safeExec('find ./server -name "*.ts" -o -name "*.js" 2>/dev/null | head -20');
  if (!routeFiles) return [];
  const routes = [];
  const routePattern = /app\.(get|post|put|patch|delete)\s*\(\s*["'\`]([^"'\`]+)["'\`]/gi;
  for (const file of routeFiles.split("\n").filter(Boolean)) {
    try {
      const content = fs.readFileSync(path.resolve(process.cwd(), file), "utf-8");
      let match;
      while ((match = routePattern.exec(content)) !== null) {
        routes.push({ method: match[1].toUpperCase(), path: match[2], file });
      }
    } catch {}
  }
  return routes;
}

function extractDbSchema() {
  const schemaFiles = safeExec('find . -name "schema.ts" -o -name "schema.js" -not -path "*/node_modules/*" 2>/dev/null');
  if (!schemaFiles) return [];
  const tables = [];
  const tablePattern = /(?:export\s+const|const)\s+(\w+)\s*=\s*(?:pgTable|sqliteTable|mysqlTable)\s*\(\s*["'\`]([^"'\`]+)["'\`]/g;
  for (const file of schemaFiles.split("\n").filter(Boolean)) {
    try {
      const content = fs.readFileSync(path.resolve(process.cwd(), file), "utf-8");
      let match;
      while ((match = tablePattern.exec(content)) !== null) {
        tables.push({ varName: match[1], tableName: match[2], file });
      }
    } catch {}
  }
  return tables;
}

function detectCodePatterns() {
  const sampleFiles = safeExec('find . -name "*.ts" -o -name "*.js" -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null | head -30');
  if (!sampleFiles) return {};
  const patterns = { asyncStyle: "unknown", errorHandling: "unknown", importStyle: "unknown" };
  let asyncAwaitCount = 0, promiseCount = 0, tryCatchCount = 0, esImportCount = 0, requireCount = 0;
  for (const file of sampleFiles.split("\n").filter(Boolean)) {
    try {
      const content = fs.readFileSync(path.resolve(process.cwd(), file), "utf-8");
      asyncAwaitCount += (content.match(/async\s+/g) || []).length;
      promiseCount += (content.match(/\.then\s*\(/g) || []).length;
      tryCatchCount += (content.match(/try\s*\{/g) || []).length;
      esImportCount += (content.match(/^import\s/gm) || []).length;
      requireCount += (content.match(/require\s*\(/g) || []).length;
    } catch {}
  }
  patterns.asyncStyle = asyncAwaitCount > promiseCount ? "async/await" : "Promises (.then)";
  patterns.errorHandling = tryCatchCount > 3 ? "try/catch blocks" : "minimal";
  patterns.importStyle = esImportCount > requireCount ? "ES modules (import)" : "CommonJS (require)";
  return patterns;
}

function getEnvVars() {
  const envFiles = [".env", ".env.example", ".env.local"];
  const vars = [];
  for (const envFile of envFiles) {
    const envPath = path.resolve(process.cwd(), envFile);
    if (fs.existsSync(envPath)) {
      const content = fs.readFileSync(envPath, "utf-8");
      for (const line of content.split("\n")) {
        const match = line.match(/^([A-Z_][A-Z0-9_]*)\s*=/);
        if (match) vars.push({ name: match[1], source: envFile });
      }
    }
  }
  return vars;
}

function getRecentCommits(count = 10) {
  const log = safeExec(\`git log --oneline -\${count} --no-decorate 2>/dev/null\`);
  return log ? log.split("\n").filter(Boolean).map(line => {
    const [hash, ...rest] = line.split(" ");
    return { hash, message: rest.join(" ") };
  }) : [];
}

function generateDevelopmentContext(appName) {
  return {
    appName,
    generatedAt: new Date().toISOString(),
    techStack: detectTechStack(),
    dependencies: getDependencies(),
    fileStructure: getFileStructure(),
    apiRoutes: extractApiRoutes(),
    dbSchema: extractDbSchema(),
    codePatterns: detectCodePatterns(),
    envVars: getEnvVars(),
    recentCommits: getRecentCommits(),
  };
}

function formatContextAsMarkdown(ctx) {
  let md = \`# Development Context: \${ctx.appName}\n\n\`;
  md += \`_Generated: \${ctx.generatedAt}_\n\n\`;
  md += \`## Tech Stack\n\`;
  for (const [k, v] of Object.entries(ctx.techStack)) md += \`- **\${k}**: \${v}\n\`;
  md += \`\n## API Routes (\${ctx.apiRoutes.length})\n\`;
  if (ctx.apiRoutes.length > 0) {
    md += "| Method | Path |\n|--------|------|\n";
    for (const r of ctx.apiRoutes) md += \`| \${r.method} | \\\`\${r.path}\\\` |\n\`;
  }
  md += \`\n## Database Tables (\${ctx.dbSchema.length})\n\`;
  for (const t of ctx.dbSchema) md += \`- \\\`\${t.tableName}\\\` (\${t.varName})\n\`;
  md += \`\n## Code Patterns\n\`;
  for (const [k, v] of Object.entries(ctx.codePatterns)) md += \`- **\${k}**: \${v}\n\`;
  md += \`\n## Recent Changes\n\`;
  for (const c of ctx.recentCommits) md += \`- \\\`\${c.hash}\\\` \${c.message}\n\`;
  return md;
}

module.exports = { generateDevelopmentContext, formatContextAsMarkdown };
