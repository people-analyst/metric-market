// FieldExchange.tsx — Field Exchange Page Component
// Feature Module: Field Exchange | Application: Metric Market
// Generated: 2026-02-12
//
// USAGE:
// 1. Copy this file to client/src/pages/field-exchange.tsx
// 2. Add route: <Route path="/field-exchange" component={FieldExchange} />
// 3. Add sidebar nav item: { title: "Fields", url: "/field-exchange", icon: ArrowLeftRight }
// 4. Install dependencies if not present: @tanstack/react-query

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeftRight, Download, RefreshCw, Plus, Trash2, Database, Link2 } from "lucide-react";

interface FieldMapping {
  id: number;
  sourceName: string;
  canonicalFieldName: string;
  confidence: number;
  sourceType: string;
  confirmedAt: string;
}

interface MappingsResponse {
  mappings: FieldMapping[];
  lastSync: string | null;
  hubUrl: string;
  appSlug: string;
}

interface ManifestResponse {
  version: string;
  totalFields: number;
  totalAliases: number;
  categories: string[];
  lastUpdated: string;
}

export default function FieldExchange() {
  const queryClient = useQueryClient();
  const [newSource, setNewSource] = useState("");
  const [newCanonical, setNewCanonical] = useState("");
  const [syncNames, setSyncNames] = useState("");

  const { data: mappingsData, isLoading: mappingsLoading } = useQuery<MappingsResponse>({
    queryKey: ["/api/field-mappings"],
  });

  const { data: manifest, isLoading: manifestLoading } = useQuery<ManifestResponse>({
    queryKey: ["/api/field-exchange/manifest"],
  });

  const addMapping = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/field-mappings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceName: newSource, canonicalFieldName: newCanonical }),
      });
      if (!res.ok) throw new Error((await res.json()).message);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/field-mappings"] });
      setNewSource("");
      setNewCanonical("");
    },
  });

  const deleteMapping = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(\`/api/field-mappings/\${id}\`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/field-mappings"] }),
  });

  const syncWithHub = useMutation({
    mutationFn: async () => {
      const names = syncNames.split(",").map(n => n.trim()).filter(Boolean);
      const res = await fetch("/api/field-exchange/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ discoveredNames: names }),
      });
      if (!res.ok) throw new Error((await res.json()).message);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/field-mappings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/field-exchange/manifest"] });
    },
  });

  if (mappingsLoading) {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-96" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const mappings = mappingsData?.mappings || [];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
              Field Exchange
            </h1>
            {manifest && (
              <Badge variant="secondary" data-testid="badge-field-count">
                {manifest.totalFields} fields / {manifest.totalAliases} aliases
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground mt-1">
            Manage canonical field mappings and sync with the hub's field library
          </p>
          {mappingsData?.lastSync && (
            <p className="text-xs text-muted-foreground mt-1">
              Last synced: {new Date(mappingsData.lastSync).toLocaleString()}
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <Database className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold" data-testid="text-mapping-count">{mappings.length}</p>
                <p className="text-xs text-muted-foreground">Local Mappings</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <ArrowLeftRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{manifest?.totalFields ?? "..."}</p>
                <p className="text-xs text-muted-foreground">Hub Canonical Fields</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                <Link2 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{manifest?.totalAliases ?? "..."}</p>
                <p className="text-xs text-muted-foreground">Known Aliases</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="mappings" className="space-y-4">
        <TabsList>
          <TabsTrigger value="mappings" data-testid="tab-mappings">Mappings</TabsTrigger>
          <TabsTrigger value="sync" data-testid="tab-sync">Sync</TabsTrigger>
        </TabsList>

        <TabsContent value="mappings">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <CardTitle className="text-base">Field Mappings</CardTitle>
              <Badge variant="secondary">{mappings.length} mapped</Badge>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4 flex-wrap">
                <Input
                  placeholder="Source column name"
                  value={newSource}
                  onChange={(e) => setNewSource(e.target.value)}
                  className="max-w-[200px]"
                  data-testid="input-source-name"
                />
                <Input
                  placeholder="Canonical field name"
                  value={newCanonical}
                  onChange={(e) => setNewCanonical(e.target.value)}
                  className="max-w-[200px]"
                  data-testid="input-canonical-name"
                />
                <Button
                  size="sm"
                  onClick={() => addMapping.mutate()}
                  disabled={!newSource || !newCanonical || addMapping.isPending}
                  data-testid="button-add-mapping"
                >
                  <Plus className="h-3.5 w-3.5 mr-1" />
                  Add
                </Button>
              </div>

              {mappings.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4">
                  No field mappings yet. Add source column names and map them to canonical field names above.
                </p>
              ) : (
                <div className="divide-y">
                  {mappings.map((m) => (
                    <div key={m.id} className="flex items-center justify-between gap-3 py-2" data-testid={\`row-mapping-\${m.id}\`}>
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <code className="text-sm bg-muted px-1.5 py-0.5 rounded-md">{m.sourceName}</code>
                        <ArrowLeftRight className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <code className="text-sm bg-muted px-1.5 py-0.5 rounded-md">{m.canonicalFieldName}</code>
                        <Badge variant="outline" className="text-xs">{m.confidence}%</Badge>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => deleteMapping.mutate(m.id)}
                        data-testid={\`button-delete-mapping-\${m.id}\`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <CardTitle className="text-base">Hub Sync</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-2">
                  Enter comma-separated column names from your data sources to discover matching canonical fields:
                </p>
                <Input
                  placeholder="e.g. EmpID, HireDate, BasePay, Department"
                  value={syncNames}
                  onChange={(e) => setSyncNames(e.target.value)}
                  data-testid="input-sync-names"
                />
              </div>
              <Button
                onClick={() => syncWithHub.mutate()}
                disabled={syncWithHub.isPending}
                data-testid="button-sync"
              >
                <RefreshCw className={\`h-3.5 w-3.5 mr-1 \${syncWithHub.isPending ? "animate-spin" : ""}\`} />
                Sync with Hub
              </Button>
              {syncWithHub.data && (
                <div className="mt-4 p-3 bg-muted rounded-md">
                  <p className="text-sm font-medium mb-2">Sync Results</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <span className="text-muted-foreground">Discovered:</span>
                    <span>{syncWithHub.data.summary?.totalDiscovered ?? 0}</span>
                    <span className="text-muted-foreground">Matched:</span>
                    <span>{syncWithHub.data.summary?.matched ?? 0}</span>
                    <span className="text-muted-foreground">Unmatched:</span>
                    <span>{syncWithHub.data.summary?.unmatched ?? 0}</span>
                    <span className="text-muted-foreground">Mappings Created:</span>
                    <span>{syncWithHub.data.summary?.mappingsCreated ?? 0}</span>
                    <span className="text-muted-foreground">Aliases Enriched:</span>
                    <span>{syncWithHub.data.summary?.aliasesEnriched ?? 0}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
