// field-exchange-routes.js — Field Exchange API Routes
// Feature Module: Field Exchange | Application: Metric Market
// Generated: 2026-02-12
//
// Provides local field mapping management and hub sync endpoints.
// Add these routes to your Express app:
//   const { registerFieldExchangeRoutes } = require("./feature-modules/field-exchange/field-exchange-routes");
//   registerFieldExchangeRoutes(app, db);

const HUB_URL = "http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev";
const APP_SLUG = "metric-market";

let localMappings = [];
let lastSync = null;

function registerFieldExchangeRoutes(app, db) {

  app.get("/api/field-mappings", (req, res) => {
    res.json({
      mappings: localMappings,
      lastSync,
      hubUrl: HUB_URL,
      appSlug: APP_SLUG,
    });
  });

  app.post("/api/field-mappings", (req, res) => {
    try {
      const { sourceName, canonicalFieldName, confidence, sourceType } = req.body;
      if (!sourceName || !canonicalFieldName) {
        return res.status(400).json({ message: "sourceName and canonicalFieldName are required" });
      }
      const existing = localMappings.find(
        m => m.sourceName === sourceName && m.canonicalFieldName === canonicalFieldName
      );
      if (existing) {
        return res.status(409).json({ message: "Mapping already exists" });
      }
      const mapping = {
        id: Date.now(),
        sourceName,
        canonicalFieldName,
        confidence: confidence || 100,
        sourceType: sourceType || "manual",
        confirmedAt: new Date().toISOString(),
      };
      localMappings.push(mapping);
      res.status(201).json(mapping);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/field-mappings/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const idx = localMappings.findIndex(m => m.id === id);
    if (idx === -1) return res.status(404).json({ message: "Mapping not found" });
    localMappings.splice(idx, 1);
    res.json({ success: true });
  });

  app.post("/api/field-exchange/sync", async (req, res) => {
    try {
      const API_KEY = process.env.HUB_API_KEY;
      if (!API_KEY) {
        return res.status(500).json({ message: "HUB_API_KEY not set in environment" });
      }
      const { discoveredNames } = req.body;
      const response = await fetch(
        `${HUB_URL}/api/hub/app/${APP_SLUG}/fields/exchange`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-API-Key": API_KEY,
          },
          body: JSON.stringify({
            discoveredNames: discoveredNames || [],
            confirmedMappings: localMappings.map(m => ({
              sourceName: m.sourceName,
              canonicalFieldName: m.canonicalFieldName,
              confidence: m.confidence,
              sourceType: m.sourceType,
            })),
          }),
        }
      );
      if (!response.ok) {
        const text = await response.text();
        return res.status(response.status).json({ message: text });
      }
      const result = await response.json();
      lastSync = new Date().toISOString();
      res.json({ ...result, lastSync });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/field-exchange/manifest", async (req, res) => {
    try {
      const API_KEY = process.env.HUB_API_KEY;
      if (!API_KEY) {
        return res.status(500).json({ message: "HUB_API_KEY not set in environment" });
      }
      const response = await fetch(
        `${HUB_URL}/api/hub/app/${APP_SLUG}/fields/manifest`,
        {
          headers: { "X-API-Key": API_KEY },
        }
      );
      if (!response.ok) {
        const text = await response.text();
        return res.status(response.status).json({ message: text });
      }
      const manifest = await response.json();
      res.json(manifest);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  // ── Data Profiling: Profile columns and submit to hub ──
  // POST /api/field-exchange/profile-and-submit
  // Body: { columns: { columnName: string[] }  }
  // Profiles each column's data and submits statistical profiles to the hub.
  app.post("/api/field-exchange/profile-and-submit", async (req, res) => {
    try {
      const API_KEY = process.env.HUB_API_KEY;
      if (!API_KEY) {
        return res.status(500).json({ message: "HUB_API_KEY not set in environment" });
      }
      const { columns } = req.body;
      if (!columns || typeof columns !== "object") {
        return res.status(400).json({ message: "columns object is required: { columnName: string[] }" });
      }

      // Inline pattern detection (mirrors SDK logic)
      function detectPattern(values) {
        const nonNull = values.filter(v => v != null && v !== "");
        if (nonNull.length === 0) return { patternType: "unknown", detectedDataType: null };
        const sample = nonNull.slice(0, 100);
        const patterns = {
          email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/,
          phone: /^[\+]?[\d\s\-\(\)\.]{7,15}$/,
          date: /^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}$/,
          datetime: /^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}[T\s]\d{1,2}:\d{2}/,
          currency: /^[\$\u00A3\u20AC\u00A5]?[\d,]+\.?\d{0,2}$/,
          percentage: /^\d+\.?\d*%$/,
          boolean: /^(true|false|yes|no|y|n|1|0)$/i,
          integer: /^-?\d+$/,
          decimal: /^-?\d+\.\d+$/,
          uuid: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i,
          url: /^https?:\/\/.+/,
        };
        for (const [type, regex] of Object.entries(patterns)) {
          const matchRate = sample.filter(v => regex.test(String(v))).length / sample.length;
          if (matchRate >= 0.7) return { patternType: type, detectedDataType: type };
        }
        const uniqueRate = new Set(nonNull).size / nonNull.length;
        if (uniqueRate < 0.1 && nonNull.length > 10) return { patternType: "categorical", detectedDataType: "categorical" };
        if (uniqueRate > 0.9) return { patternType: "identifier", detectedDataType: "identifier" };
        return { patternType: "free_text", detectedDataType: "free_text" };
      }

      const profiles = [];
      for (const [name, values] of Object.entries(columns)) {
        const arr = Array.isArray(values) ? values : [];
        const nonNull = arr.filter(v => v != null && v !== "");
        const { patternType, detectedDataType } = detectPattern(arr);
        const uniqueSet = new Set(nonNull);
        const topValues = uniqueSet.size <= 20 ? Array.from(uniqueSet).slice(0, 10).map(String) : null;
        const lengths = nonNull.map(v => String(v).length);
        profiles.push({
          sourceName: name,
          totalRows: arr.length,
          nullRate: arr.length > 0 ? (arr.length - nonNull.length) / arr.length : 0,
          uniqueCount: uniqueSet.size,
          uniqueRate: arr.length > 0 ? uniqueSet.size / arr.length : 0,
          patternType,
          detectedDataType,
          minLength: lengths.length > 0 ? Math.min(...lengths) : null,
          maxLength: lengths.length > 0 ? Math.max(...lengths) : null,
          topValues,
        });
      }

      const response = await fetch(
        `${HUB_URL}/api/hub/app/${APP_SLUG}/fields/profiles`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-API-Key": API_KEY },
          body: JSON.stringify({ profiles }),
        }
      );
      if (!response.ok) {
        const text = await response.text();
        return res.status(response.status).json({ message: text });
      }
      const result = await response.json();
      res.json(result);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  // GET /api/field-exchange/profiles — View profiles submitted for this app
  app.get("/api/field-exchange/profiles", async (req, res) => {
    try {
      const API_KEY = process.env.HUB_API_KEY;
      if (!API_KEY) {
        return res.status(500).json({ message: "HUB_API_KEY not set in environment" });
      }
      const response = await fetch(
        `${HUB_URL}/api/data-profiles?appSlug=${APP_SLUG}`,
        {
          headers: { "X-API-Key": API_KEY },
        }
      );
      if (!response.ok) {
        const text = await response.text();
        return res.status(response.status).json({ message: text });
      }
      const profiles = await response.json();
      res.json(profiles);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
}

module.exports = { registerFieldExchangeRoutes };
