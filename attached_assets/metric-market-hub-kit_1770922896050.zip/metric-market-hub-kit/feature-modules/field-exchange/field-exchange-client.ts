/**
 * People Analytics Toolbox — Field Exchange Client SDK
 * =====================================================
 * Drop this file into any spoke application to integrate with the
 * People Analytics Hub's canonical field library.
 *
 * SETUP:
 *   1. Copy this file into your project
 *   2. Set your hub URL, app slug, and API key (see below)
 *   3. Call the methods to sync fields with the hub
 *
 * USAGE:
 *   import { FieldExchangeClient } from "./field-exchange-client";
 *
 *   const client = new FieldExchangeClient({
 *     hubUrl: "https://your-hub.replit.app",
 *     appSlug: "my-app-slug",
 *     apiKey: "pat_abc123...",
 *   });
 *
 *   // Check if the hub's field library has changed
 *   const manifest = await client.getManifest();
 *
 *   // Send discovered column names and get matches back
 *   const result = await client.exchange({
 *     discoveredNames: ["EmpID", "HireDate", "BasePay"],
 *     confirmedMappings: [
 *       { sourceName: "EmpID", canonicalFieldName: "employee_id" },
 *     ],
 *   });
 *
 * No external dependencies required — uses built-in fetch().
 */

// ── Types ──────────────────────────────────────────────────

export interface FieldExchangeConfig {
  hubUrl: string;
  appSlug: string;
  apiKey: string;
}

export interface ManifestResponse {
  version: string;
  totalFields: number;
  totalAliases: number;
  categories: string[];
  lastUpdated: string;
}

export interface FieldMatch {
  field: {
    id: number;
    name: string;
    displayName: string;
    category: string;
    dataType: string;
    aliases: string[];
  };
  confidence: number;
  matchType: string;
}

export interface MatchResult {
  inputName: string;
  matches: FieldMatch[];
}

export interface ConfirmedMapping {
  sourceName: string;
  canonicalFieldName?: string;
  canonicalFieldId?: number;
  confidence?: number;
  sourceType?: string;
}

export interface ExchangeRequest {
  discoveredNames?: string[];
  confirmedMappings?: ConfirmedMapping[];
  sourceType?: string;
  clientManifestVersion?: string;
}

export interface ExchangeResponse {
  manifestVersion: string;
  fieldsChanged: boolean;
  matches: MatchResult[];
  createdMappings: Array<{
    sourceName: string;
    canonicalFieldName: string;
    confidence: number;
  }>;
  aliasesAdded: Array<{
    fieldName: string;
    newAlias: string;
  }>;
  unmatchedNames: string[];
  summary: {
    totalDiscovered: number;
    matched: number;
    unmatched: number;
    mappingsCreated: number;
    aliasesEnriched: number;
    fieldsProposed: number;
  };
}

export interface CanonicalField {
  id: number;
  name: string;
  displayName: string;
  description: string;
  category: string;
  dataType: string;
  aliases: string[];
  sourceTypes: string[];
  isCustom: boolean;
}

// ── Client ─────────────────────────────────────────────────

export class FieldExchangeClient {
  private hubUrl: string;
  private appSlug: string;
  private apiKey: string;
  private lastManifestVersion: string | null = null;

  constructor(config: FieldExchangeConfig) {
    this.hubUrl = config.hubUrl.replace(/\/$/, "");
    this.appSlug = config.appSlug;
    this.apiKey = config.apiKey;
  }

  private get baseUrl(): string {
    return `${this.hubUrl}/api/hub/app/${this.appSlug}/fields`;
  }

  private async request<T>(
    path: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    const res = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": this.apiKey,
        ...(options.headers || {}),
      },
    });

    if (!res.ok) {
      const body = await res.text();
      throw new FieldExchangeError(
        `Hub returned ${res.status}: ${body}`,
        res.status,
        body
      );
    }

    return res.json() as Promise<T>;
  }

  // ── Core Methods ───────────────────────────────────────

  /**
   * Fetch the hub's field library manifest.
   * Use this to check if the field library has changed since your
   * last sync, without transferring all the field data.
   */
  async getManifest(): Promise<ManifestResponse> {
    const manifest = await this.request<ManifestResponse>("/manifest");
    this.lastManifestVersion = manifest.version;
    return manifest;
  }

  /**
   * Perform a field exchange with the hub.
   *
   * Send discovered column names from your data sources, plus any
   * confirmed mappings from your users. The hub returns:
   * - Auto-matched fields for each discovered name
   * - Records of created mappings
   * - Any new aliases added to canonical fields
   * - Unmatched names that need manual review
   */
  async exchange(request: ExchangeRequest): Promise<ExchangeResponse> {
    const body: ExchangeRequest = {
      ...request,
      clientManifestVersion:
        request.clientManifestVersion || this.lastManifestVersion || undefined,
    };

    const result = await this.request<ExchangeResponse>("/exchange", {
      method: "POST",
      body: JSON.stringify(body),
    });

    this.lastManifestVersion = result.manifestVersion;
    return result;
  }

  /**
   * Fetch the full canonical field library from the hub.
   * Useful for populating dropdown selectors or building
   * local lookup tables.
   */
  async getAllFields(): Promise<CanonicalField[]> {
    return this.request<CanonicalField[]>("");
  }

  /**
   * Quick-match a list of column names without creating any
   * mappings. Useful for previewing matches before confirming.
   */
  async matchNames(names: string[]): Promise<MatchResult[]> {
    return this.request<MatchResult[]>("/match", {
      method: "POST",
      body: JSON.stringify({ names }),
    });
  }

  // ── Convenience Methods ────────────────────────────────

  /**
   * Full sync workflow in one call:
   * 1. Checks the manifest to see if anything changed
   * 2. If changed (or forced), sends discovered names + confirmed mappings
   * 3. Returns the exchange result, or null if nothing changed
   */
  async sync(options: {
    discoveredNames: string[];
    confirmedMappings?: ConfirmedMapping[];
    sourceType?: string;
    force?: boolean;
  }): Promise<ExchangeResponse | null> {
    const manifest = await this.getManifest();

    if (
      !options.force &&
      this.lastManifestVersion &&
      manifest.version === this.lastManifestVersion
    ) {
      return null;
    }

    return this.exchange({
      discoveredNames: options.discoveredNames,
      confirmedMappings: options.confirmedMappings || [],
      sourceType: options.sourceType,
      clientManifestVersion: this.lastManifestVersion || undefined,
    });
  }

  /**
   * Returns only high-confidence matches (>= threshold) from
   * a list of column names. Handy for auto-mapping without
   * user confirmation.
   */
  async autoMatch(
    names: string[],
    confidenceThreshold: number = 85
  ): Promise<Map<string, FieldMatch>> {
    const results = await this.matchNames(names);
    const matches = new Map<string, FieldMatch>();

    for (const result of results) {
      if (
        result.matches.length > 0 &&
        result.matches[0].confidence >= confidenceThreshold
      ) {
        matches.set(result.inputName, result.matches[0]);
      }
    }

    return matches;
  }

  // ── Data Profiling Methods ─────────────────────────────

  /**
   * Profile an array of column data and generate a data profile.
   * Analyzes pattern type, null rate, unique count, value distribution,
   * and format patterns — WITHOUT sending raw PII to the hub.
   *
   * @param sourceName - The column/field name
   * @param values - Array of raw values from the column (strings)
   * @returns A DataProfile object ready to submit to the hub
   */
  profileColumn(sourceName: string, values: (string | number | null | undefined)[]): DataProfile {
    const total = values.length;
    const nonNull = values.filter(v => v !== null && v !== undefined && v !== "");
    const nullCount = total - nonNull.length;
    const nullRate = total > 0 ? nullCount / total : 0;

    const strValues = nonNull.map(v => String(v).trim());
    const uniqueValues = new Set(strValues);
    const uniqueCount = uniqueValues.size;
    const uniqueRate = nonNull.length > 0 ? uniqueCount / nonNull.length : 0;

    const lengths = strValues.map(v => v.length);
    const minLength = lengths.length > 0 ? Math.min(...lengths) : 0;
    const maxLength = lengths.length > 0 ? Math.max(...lengths) : 0;
    const avgLength = lengths.length > 0 ? lengths.reduce((a, b) => a + b, 0) / lengths.length : 0;

    const patternType = this.detectPatternType(strValues);

    const topValues = this.getTopValues(strValues, 10);

    let numericMin: number | undefined;
    let numericMax: number | undefined;
    let numericMean: number | undefined;

    if (["integer", "decimal", "currency", "percentage"].includes(patternType)) {
      const nums = strValues
        .map(v => parseFloat(v.replace(/[$€£¥,%\s]/g, "")))
        .filter(n => !isNaN(n));
      if (nums.length > 0) {
        numericMin = Math.min(...nums);
        numericMax = Math.max(...nums);
        numericMean = nums.reduce((a, b) => a + b, 0) / nums.length;
      }
    }

    const sampleFormats = this.detectFormats(strValues.slice(0, 100));
    const formatPattern = sampleFormats[0] || undefined;

    return {
      sourceName,
      patternType,
      totalRows: total,
      nullCount,
      nullRate: Math.round(nullRate * 10000) / 10000,
      uniqueCount,
      uniqueRate: Math.round(uniqueRate * 10000) / 10000,
      minLength,
      maxLength,
      avgLength: Math.round(avgLength * 100) / 100,
      sampleFormats,
      topValues,
      numericMin,
      numericMax,
      numericMean: numericMean !== undefined ? Math.round(numericMean * 100) / 100 : undefined,
      formatPattern,
      detectedDataType: this.patternToDataType(patternType),
    };
  }

  /**
   * Profile multiple columns at once.
   */
  profileColumns(columns: Array<{ name: string; values: (string | number | null | undefined)[] }>): DataProfile[] {
    return columns.map(col => this.profileColumn(col.name, col.values));
  }

  /**
   * Submit data profiles to the hub for storage and matching enhancement.
   */
  async submitProfiles(profiles: DataProfile[]): Promise<ProfileSubmitResponse> {
    return this.request<ProfileSubmitResponse>("/profiles", {
      method: "POST",
      body: JSON.stringify({ profiles }),
    });
  }

  /**
   * Profile columns and submit to hub in one call.
   */
  async profileAndSubmit(
    columns: Array<{ name: string; values: (string | number | null | undefined)[] }>
  ): Promise<ProfileSubmitResponse> {
    const profiles = this.profileColumns(columns);
    return this.submitProfiles(profiles);
  }

  // ── Private Profiling Helpers ───────────────────────────

  private detectPatternType(values: string[]): string {
    if (values.length === 0) return "unknown";

    const sample = values.slice(0, 200);
    const patterns: Record<string, number> = {};

    for (const val of sample) {
      const lower = val.toLowerCase();
      if (/^[\w.+-]+@[\w.-]+\.\w+$/.test(val)) { patterns.email = (patterns.email || 0) + 1; }
      else if (/^https?:\/\//.test(val)) { patterns.url = (patterns.url || 0) + 1; }
      else if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val)) { patterns.uuid = (patterns.uuid || 0) + 1; }
      else if (/^\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:/.test(val)) { patterns.datetime = (patterns.datetime || 0) + 1; }
      else if (/^\d{4}[-/]\d{2}[-/]\d{2}$/.test(val)) { patterns.date = (patterns.date || 0) + 1; }
      else if (/^\d{1,2}[-/]\d{1,2}[-/]\d{2,4}$/.test(val)) { patterns.date = (patterns.date || 0) + 1; }
      else if (/^[+]?[\d\s\-()]{7,15}$/.test(val)) { patterns.phone = (patterns.phone || 0) + 1; }
      else if (/^[$€£¥]?[\d,]+\.?\d*$/.test(val) && /\d/.test(val)) { patterns.currency = (patterns.currency || 0) + 1; }
      else if (/^\d+\.?\d*\s?%$/.test(val)) { patterns.percentage = (patterns.percentage || 0) + 1; }
      else if (/^(true|false|yes|no|1|0|y|n)$/i.test(lower)) { patterns.boolean = (patterns.boolean || 0) + 1; }
      else if (/^-?\d+$/.test(val)) { patterns.integer = (patterns.integer || 0) + 1; }
      else if (/^-?\d+\.\d+$/.test(val)) { patterns.decimal = (patterns.decimal || 0) + 1; }
      else { patterns.free_text = (patterns.free_text || 0) + 1; }
    }

    const totalSampled = sample.length;
    const entries = Object.entries(patterns).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) return "unknown";

    const [topPattern, topCount] = entries[0];

    if (topCount / totalSampled >= 0.7) return topPattern;

    if (topPattern === "integer" || topPattern === "decimal") {
      const numericTotal = (patterns.integer || 0) + (patterns.decimal || 0) + (patterns.currency || 0);
      if (numericTotal / totalSampled >= 0.7) return topPattern;
    }

    const uniqueRatio = new Set(sample).size / sample.length;
    if (uniqueRatio < 0.1 && sample.length > 10) return "categorical";
    if (topPattern === "free_text" && topCount / totalSampled >= 0.5) return "free_text";

    return uniqueRatio < 0.3 ? "categorical" : "identifier";
  }

  private getTopValues(values: string[], limit: number): Array<{ value: string; count: number }> {
    const counts: Record<string, number> = {};
    for (const v of values) {
      counts[v] = (counts[v] || 0) + 1;
    }

    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([value, count]) => ({
        value: value.length > 50 ? value.substring(0, 47) + "..." : value,
        count,
      }));
  }

  private detectFormats(values: string[]): string[] {
    const formats = new Set<string>();
    for (const val of values) {
      if (/^\d{4}-\d{2}-\d{2}$/.test(val)) formats.add("YYYY-MM-DD");
      else if (/^\d{2}\/\d{2}\/\d{4}$/.test(val)) formats.add("MM/DD/YYYY");
      else if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(val)) formats.add("ISO-8601");
      else if (/^\d{1,2}\/\d{1,2}\/\d{2}$/.test(val)) formats.add("M/D/YY");
      else if (/^[$]\d/.test(val)) formats.add("$N.NN");
      else if (/^[\w.+-]+@[\w.-]+\.\w+$/.test(val)) formats.add("email");
      else if (/^\d{3}-\d{2}-\d{4}$/.test(val)) formats.add("NNN-NN-NNNN");
      else if (/^\(\d{3}\)\s?\d{3}-\d{4}$/.test(val)) formats.add("(NNN) NNN-NNNN");
      if (formats.size >= 5) break;
    }
    return Array.from(formats);
  }

  private patternToDataType(pattern: string): string {
    const map: Record<string, string> = {
      email: "email", phone: "phone", date: "date", datetime: "datetime",
      currency: "currency", percentage: "percentage", boolean: "boolean",
      integer: "integer", decimal: "number", uuid: "string",
      url: "url", ssn: "string", categorical: "string",
      free_text: "string", identifier: "string", unknown: "string",
    };
    return map[pattern] || "string";
  }
}

// ── Types for Data Profiling ─────────────────────────────

export interface DataProfile {
  sourceName: string;
  patternType: string;
  totalRows: number;
  nullCount: number;
  nullRate: number;
  uniqueCount: number;
  uniqueRate: number;
  minLength: number;
  maxLength: number;
  avgLength: number;
  sampleFormats: string[];
  topValues: Array<{ value: string; count: number }>;
  numericMin?: number;
  numericMax?: number;
  numericMean?: number;
  formatPattern?: string;
  detectedDataType: string;
}

export interface ProfileSubmitResponse {
  saved: number;
  skipped: number;
  results: Array<{
    sourceName: string;
    status: string;
    id?: number;
    canonicalFieldId?: number | null;
    reason?: string;
  }>;
}

// ── Error Class ──────────────────────────────────────────

export class FieldExchangeError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public responseBody: string
  ) {
    super(message);
    this.name = "FieldExchangeError";
  }
}
