# Field Exchange Feature Module
## Application: Metric Market | Generated: 2026-02-12

This module integrates your spoke application with the hub's canonical field library.
It provides a zero-dependency TypeScript SDK for hub communication, Express routes for
local mapping management and hub sync, and a React page component for the field mapping UI.

## Files

| File | Purpose | Destination |
|------|---------|-------------|
| `field-exchange-client.ts` | TypeScript SDK — hub field library client (zero dependencies) | Project root or `server/` |
| `field-exchange-routes.js` | Express routes for local mappings + hub sync | Project root or `server/` |
| `FieldExchange.tsx` | React page with mapping management + sync UI | `client/src/pages/` |

## Quick Setup

### 1. Backend Routes
```javascript
// In your Express server setup:
const { registerFieldExchangeRoutes } = require("./feature-modules/field-exchange/field-exchange-routes");
registerFieldExchangeRoutes(app, db);
```

### 2. Frontend Route
```tsx
// In your App.tsx router:
import FieldExchange from "@/pages/field-exchange";

<Route path="/field-exchange" component={FieldExchange} />
```

### 3. Sidebar Navigation
```tsx
// Add to your sidebar nav items:
import { ArrowLeftRight } from "lucide-react";
{ title: "Fields", url: "/field-exchange", icon: ArrowLeftRight }
```

### 4. Environment Variables
Set `HUB_API_KEY` in your Replit Secrets to your app's API key from the hub.

### 5. Using the SDK Directly
```typescript
import { FieldExchangeClient } from "./field-exchange-client";

const client = new FieldExchangeClient({
  hubUrl: "http://682eb7bd-f279-41bd-ac9e-1ad52cd23036-00-sc7pg47dpokt.spock.replit.dev",
  appSlug: "metric-market",
  apiKey: process.env.HUB_API_KEY,
});

// Check the hub's field library version
const manifest = await client.getManifest();

// Auto-match column names (>= 85% confidence)
const matches = await client.autoMatch(["EmpID", "HireDate", "BasePay"]);

// Full sync: check manifest, exchange discovered names + confirmed mappings
const result = await client.sync({
  discoveredNames: ["EmpID", "HireDate", "BasePay"],
  confirmedMappings: [{ sourceName: "EmpID", canonicalFieldName: "employee_id" }],
});
```

### 6. Data Profiling (NEW)
Profile your data columns and submit statistical summaries to the hub for smarter matching:
```typescript
// Profile columns and submit to hub (no raw data sent — only statistics)
const result = await client.profileAndSubmit({
  employee_id: ["E001", "E002", "E003"],
  hire_date: ["2020-01-15", "2021-03-22", null],
  base_salary: ["75000", "82000", "91000"],
});

// Or profile locally first, review, then submit
const profiles = client.profileColumns({
  employee_id: ["E001", "E002", "E003"],
});
await client.submitProfiles(profiles);
```
The hub uses profile data (pattern types, null rates, data types) to boost field matching accuracy.

## Hub API Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/hub/app/:slug/fields/manifest` | GET | Field library version check |
| `/api/hub/app/:slug/fields/exchange` | POST | Bulk sync with matches + mappings |
| `/api/hub/app/:slug/fields/match` | POST | Quick match column names |
| `/api/hub/app/:slug/fields/profiles` | POST | Submit data profiles for matching boost |
| `/api/fields` | GET | Full canonical field library |

## Local Endpoints (from field-exchange-routes.js)

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/field-mappings` | GET | List local mappings |
| `/api/field-mappings` | POST | Add local mapping |
| `/api/field-mappings/:id` | DELETE | Remove local mapping |
| `/api/field-exchange/sync` | POST | Sync with hub |
| `/api/field-exchange/manifest` | GET | Check hub field library version |
| `/api/field-exchange/profile-and-submit` | POST | Profile columns and submit to hub |
| `/api/field-exchange/profiles` | GET | View submitted profiles |

## Features

- **Auto-matching**: Hub matches source column names to canonical fields using normalized name comparison
- **Alias enrichment**: Confirmed mappings automatically add source names as aliases to canonical fields
- **Bi-directional sync**: Spoke sends discovered names, hub returns matches and creates mappings
- **Data profiling**: Submit statistical column profiles to improve matching accuracy (no raw PII sent)
- **66 canonical fields** covering 10 HRIS platforms with 385+ aliases
- **Confidence scoring**: Each match includes a confidence percentage with data type boosting
- **Local mapping management**: Add, remove, and review field mappings locally before syncing
