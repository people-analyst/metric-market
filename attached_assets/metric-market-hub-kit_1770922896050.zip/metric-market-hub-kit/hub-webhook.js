// hub-webhook.js — Standard Webhook + Health + Specifications Routes
// Application: Metric Market (metric-market)
// Generated: 2026-02-12
//
// Add these routes to your Express app for full hub integration.
// All spoke apps MUST expose these endpoints identically.

const hubClient = require("./hub-client");
const fs = require("fs");

module.exports = function registerHubRoutes(app) {

  // 1. HEALTH ENDPOINT — Required for hub monitoring
  app.get("/health", (req, res) => {
    res.json({
      status: "ok",
      app: "metric-market",
      timestamp: new Date().toISOString(),
    });
  });

  // 2. WEBHOOK HANDLER — Receives directive notifications in real-time
  app.post("/api/hub-webhook", async (req, res) => {
    const { event, directive } = req.body;

    if (event === "directive.created" && directive) {
      console.log(
        `[Hub] ${directive.priority} ${directive.type}: ${directive.title}`
      );
      try {
        await hubClient.acknowledgeDirective(directive.id);
      } catch (err) {
        console.error("[Hub] Failed to acknowledge:", err.message);
      }
    }

    res.json({ received: true });
  });

  // 3. SPECIFICATIONS ENDPOINT — Lets the hub pull your docs on demand
  //    Serves replit.md content for documentation scoring.
  app.get("/api/specifications", (req, res) => {
    try {
      const content = fs.readFileSync("replit.md", "utf-8");
      res.type("text/plain").send(content);
    } catch {
      res.status(404).json({ message: "No documentation found" });
    }
  });

};
