// directive-executor.js — Automatic Directive Processing with Claude AI
// Application: Metric Market (metric-market)
// Generated: 2026-02-12
//
// PREREQUISITE: Set up the Anthropic AI integration in your Replit project.
// Search for "Anthropic" in the Replit integrations panel to add it.
// This handles API key management automatically.

const Anthropic = require("@anthropic-ai/sdk");
const hubClient = require("./hub-client");
const fs = require("fs");
const path = require("path");

const anthropic = new Anthropic();

async function processDirective(directive) {
  console.log(`[Directive Executor] Processing: ${directive.title} (${directive.type})`);

  await hubClient.updateDirective(directive.id, "acknowledged",
    "Auto-executor received this directive and is processing it."
  );

  try {
    let appContext = "";
    try {
      appContext = fs.readFileSync(path.join(process.cwd(), "replit.md"), "utf-8");
    } catch { appContext = "No replit.md found."; }

    const analysis = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      messages: [{
        role: "user",
        content: `You are an AI assistant helping execute a directive for the "${directive.type}" category in a People Analytics spoke application.

APP CONTEXT (from replit.md):
${appContext.slice(0, 3000)}

DIRECTIVE:
- Type: ${directive.type}
- Priority: ${directive.priority}
- Title: ${directive.title}
- Description: ${directive.description}

Analyze this directive and respond in JSON:
{
  "summary": "Brief summary of what this directive asks",
  "canAutoExecute": true/false,
  "reason": "Why it can or cannot be auto-executed",
  "steps": ["Step 1...", "Step 2..."],
  "completionResponse": "Response to send back to the hub"
}

Things that CAN be auto-executed: documentation updates, config changes, adding standard endpoints.
Things that CANNOT: major feature development, database schema changes, complex refactors.`
      }]
    });

    const responseText = analysis.content[0].text;
    let parsed;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : responseText);
    } catch {
      parsed = { summary: responseText, canAutoExecute: false, reason: "Could not parse AI response", completionResponse: responseText };
    }

    if (parsed.canAutoExecute) {
      await hubClient.updateDirective(directive.id, "in_progress",
        `Auto-executing: ${parsed.summary}`
      );

      if (directive.type === "doc_upgrade_request") {
        try {
          const docContent = fs.readFileSync(path.join(process.cwd(), "replit.md"), "utf-8");
          await hubClient.pushDocumentation(docContent, "auto");
        } catch (e) {
          console.log("[Directive Executor] Could not push docs:", e.message);
        }
      }

      await hubClient.updateDirective(directive.id, "completed", parsed.completionResponse);
      console.log(`[Directive Executor] Completed: ${directive.title}`);
    } else {
      await hubClient.updateDirective(directive.id, "acknowledged",
        `Requires manual intervention: ${parsed.reason}. Summary: ${parsed.summary}`
      );
      console.log(`[Directive Executor] Needs manual action: ${directive.title}`);
    }
  } catch (err) {
    console.error(`[Directive Executor] Error: ${err.message}`);
    await hubClient.updateDirective(directive.id, "acknowledged",
      `Auto-executor error: ${err.message}. Manual intervention required.`
    );
  }
}

async function processAllPending() {
  try {
    const directives = await hubClient.fetchDirectives("pending");
    console.log(`[Directive Executor] Found ${directives.length} pending directive(s)`);
    for (const directive of directives) {
      await processDirective(directive);
    }
    return { processed: directives.length };
  } catch (err) {
    console.error("[Directive Executor] Error:", err.message);
    return { processed: 0, error: err.message };
  }
}

module.exports = { processDirective, processAllPending };
