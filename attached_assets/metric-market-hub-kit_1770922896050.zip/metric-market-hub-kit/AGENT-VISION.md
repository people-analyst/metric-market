# People Analytics Toolbox — Developer Agent Guide

Generated: 2026-02-12 | Kit Version: 2026-02-12-mljtre99
Target Application: Metric Market (metric-market)

---

## 1. The Hub Agent — AI Brain of the Ecosystem

The Hub includes an AI-powered agent built on Claude (claude-sonnet-4-5) via Replit AI Integrations. This agent has cross-application visibility — it can see the status of all registered apps, their documentation quality, pending directives, active Kanban cards, and the compiled architecture document.

### What the Agent Can Do
- **Answer questions** about any application in the ecosystem
- **Plan features** that span multiple applications
- **Debug cross-app issues** by examining app states and directive histories
- **Review code** and suggest improvements following ecosystem standards
- **Generate documentation** matching Hub quality criteria
- **Coordinate development** across spoke applications
- **Track progress** via the shared Kanban board
- **Manage Kanban cards** — create, update, and deploy cards to the Kanban board and spoke apps
- **Push cards to spoke apps** — deploy task/feature/bug cards directly into spoke app databases via `/api/receive-cards`

### How It Works
1. User sends a message via the Hub Agent chat interface
2. Hub constructs a dynamic system prompt from: enabled roles + live ecosystem context
3. Ecosystem context includes: all app statuses, doc scores, pending directives, Kanban board summary
4. Claude responds with streaming SSE, drawing on the full ecosystem awareness
5. Conversation history is maintained in the database for continuity

---

## 2. Configurable Role System

The agent's capabilities are controlled by a role toggle system. Each role injects specialized instructions into the system prompt, shaping how the agent responds. Roles are organized into 9 categories with 31 total capabilities.

### Software Engineering

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Code Review & Quality | `code_review` | Enabled | Review code for bugs, best practices, performance issues, and maintainability across all applications |
| Feature Development | `feature_dev` | Enabled | Plan and implement new features, design APIs, and create technical specifications |
| Bug Fixing & Debugging | `bug_fixing` | Enabled | Diagnose issues, trace root causes, and provide targeted fixes across the application ecosystem |
| Testing & QA | `testing_qa` | Enabled | Design test strategies, write test cases, and validate application behavior |
| Refactoring & Technical Debt | `refactoring` | Enabled | Identify and address technical debt, improve code structure, and optimize implementations |
| API Design & Development | `api_design` | Enabled | Design RESTful APIs, define contracts, and ensure consistency across the ecosystem |

### DevOps & Infrastructure

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Deployment & Release | `deployment` | Enabled | Manage deployments, release processes, and environment configurations |
| Monitoring & Alerting | `monitoring` | Enabled | Set up health monitoring, alerting, and observability across applications |
| Performance Optimization | `performance` | Enabled | Identify bottlenecks, optimize queries, and improve application performance |
| Environment Management | `env_management` | Enabled | Manage environment variables, secrets, and configuration across applications |

### Cybersecurity

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Vulnerability Assessment | `vuln_scanning` | Enabled | Scan for security vulnerabilities, dependency issues, and potential attack vectors |
| Access Control Review | `access_control` | Enabled | Review authentication, authorization, and API key management across the ecosystem |
| Dependency Auditing | `dependency_audit` | Enabled | Audit third-party dependencies for known vulnerabilities and license compliance |
| Security Compliance | `compliance` | Enabled | Ensure applications meet security standards and best practices |

### Data Engineering

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Data Pipeline Design | `pipeline_design` | Enabled | Design ETL/ELT pipelines, data flows, and transformation logic |
| Schema Design & Migration | `schema_design` | Enabled | Design database schemas, plan migrations, and ensure data integrity |
| Data Quality & Validation | `data_quality` | Enabled | Implement data quality checks, validation rules, and data cleansing processes |
| Data Integration | `data_integration` | Enabled | Design cross-application data integration patterns and shared data contracts |

### Data Science & Analytics

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Data Analysis & Insights | `data_analysis` | Enabled | Analyze patterns, generate insights, and create data-driven recommendations |
| Reporting & Visualization | `reporting` | Enabled | Design dashboards, reports, and data visualization strategies |

### Data Science

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Model Development | `model_dev` | Enabled | Develop, evaluate, and deploy machine learning models |

### Architecture & Design

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| System Architecture | `system_design` | Enabled | Design system architecture, evaluate trade-offs, and plan technical evolution |
| Cross-App Feature Planning | `cross_app_planning` | Enabled | Coordinate feature development across multiple applications in the ecosystem |
| Design Patterns & Standards | `design_patterns` | Enabled | Establish and enforce design patterns, coding standards, and conventions |

### Project Management

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Sprint Planning & Estimation | `sprint_planning` | Enabled | Help plan sprints, estimate effort, and prioritize backlog items |
| Task Breakdown & Tracking | `task_breakdown` | Enabled | Break complex work into actionable tasks and track progress |
| Risk Assessment | `risk_assessment` | Enabled | Identify technical risks, dependencies, and potential blockers |

### Documentation

| Role | Key | Default | Description |
|------|-----|---------|-------------|
| Documentation Generation | `doc_generation` | Enabled | Generate and maintain technical documentation across applications |
| Standards Enforcement | `standards_enforcement` | Enabled | Ensure documentation meets hub quality standards across all apps |
| API Documentation | `api_docs` | Enabled | Create and maintain API documentation with examples and schemas |
| Runbook & Operations Docs | `runbook_creation` | Enabled | Create operational runbooks, troubleshooting guides, and incident procedures |

### How Roles Work
- Each role has a toggle (enabled/disabled) in the Hub UI at `/agent/roles`
- Enabled roles inject their specialized system prompt into every agent conversation
- Multiple roles compose together — enabling "Code Review" + "Security Auditing" creates an agent that reviews code with security in mind
- Roles can be changed at any time; changes take effect on the next message

---

## 3. Spoke Agent Integration — The Directive Executor

Spoke applications can participate in the AI ecosystem by running their own directive executor. This is an AI-powered module that automatically processes incoming directives from the Hub.

### How It Works

1. Hub creates a directive (e.g., "Update your documentation to include API rate limits")
2. Directive arrives via webhook or polling
3. Directive executor sends the directive + app context (replit.md) to Claude
4. Claude analyzes whether the directive can be auto-executed
5. If yes: executor processes it and marks as completed
6. If no: executor acknowledges and flags for manual intervention

### What Can Be Auto-Executed
- Documentation updates and section additions
- Configuration changes
- Adding standard endpoints
- Pushing updated docs to the Hub

### What Requires Manual Intervention
- Major feature development
- Database schema changes
- Complex refactors
- Security-sensitive changes

### Setting Up the Directive Executor

1. Add the Anthropic AI integration to your Replit project (handles API key management)
2. Include `directive-executor.js` from this kit
3. Wire it into your webhook handler:

```javascript
const { processDirective } = require("./directive-executor");

app.post("/api/hub-webhook", async (req, res) => {
  const { event, directive } = req.body;
  if (event === "directive.created" && directive) {
    // Process asynchronously — don't block the webhook response
    processDirective(directive).catch(err =>
      console.error("[Directive Executor] Error:", err.message)
    );
  }
  res.json({ received: true });
});
```

4. Optionally, add a manual trigger route:

```javascript
const { processAllPending } = require("./directive-executor");

app.post("/api/process-directives", async (req, res) => {
  const result = await processAllPending();
  res.json(result);
});
```

---

## 4. Future Vision — Where This Is Headed

### Spoke Developer Agents
Each application will eventually have its own developer agent with:
- **Local context** — Deep knowledge of its own codebase via replit.md
- **Hub connectivity** — Ability to query the Hub for ecosystem-wide information
- **Kanban awareness** — Can create, update, and track its own development cards
- **Directive processing** — Autonomous handling of Hub instructions
- **Cross-app collaboration** — Agents in different apps can coordinate through the Hub

### Agent-to-Agent Communication
The Hub agent serves as the coordinator. Future capabilities include:
- Hub agent delegates sub-tasks to spoke agents via directives
- Spoke agents report progress back through directive status updates
- Kanban cards are created and updated by agents as work progresses
- Architecture document auto-updates as agents modify their applications

### Role Evolution
- Custom roles can be created for specific project needs
- Role capabilities will expand to include tool use (file editing, API calls)
- Role permissions will control what agents can modify autonomously vs. requiring approval
- Spoke apps will be able to request specific Hub agent roles for their context

---

## 5. Integration Patterns for Spoke Developers

### Pattern A: Passive Integration (Minimum)
- Expose /health, /api/hub-webhook, /api/specifications
- Push documentation via hub-client.js
- Manually handle directives

### Pattern B: Active Integration (Recommended)
- Everything in Pattern A
- Auto-acknowledge directives via webhook handler
- Poll for pending directives on startup
- Create Kanban cards for tracked work items
- Push documentation automatically on changes

### Pattern C: AI-Powered Integration (Advanced)
- Everything in Pattern B
- Run directive-executor.js with Claude
- Auto-process documentation upgrade requests
- Agent-assisted feature planning via Hub agent context
- Automated Kanban card management
- Accept card deployments via receive-cards.js (AI agent can push tasks directly)
- Deploy cards back to Kanban via kanban-client.js deployCards()

---

## 6. Card Deployment — AI-Driven Project Management

### Overview
The card deployment system enables the Hub AI agent (and authorized services) to push development cards directly to spoke apps and the central Kanban board. This creates a closed loop: the AI plans work, creates cards, pushes them to the right apps, and tracks their progress.

### How It Works

1. **Hub AI agent** analyzes a request and identifies tasks for specific apps
2. Agent creates card objects with title, type, priority, description, acceptance criteria
3. Cards are deployed via `POST /api/kanban/deploy-cards` (to Kanban) or `POST /api/receive-cards` (directly to spoke)
4. Spoke apps receive cards in their local database, visible to their local agents
5. Progress is tracked through Kanban status updates

### Setting Up Card Receiving

1. Include `receive-cards.js` from the Dev Kit
2. Set `DEPLOY_SECRET` in your Replit Secrets (same value across all ecosystem apps)
3. Create the `kanban_cards` table (schema in receive-cards.js header)
4. Register the route:

\`\`\`javascript
const registerCardReceiver = require("./receive-cards");
const { Pool } = require("pg");
const db = new Pool({ connectionString: process.env.DATABASE_URL });
registerCardReceiver(app, db);
\`\`\`

### Deploying Cards from Your App

\`\`\`javascript
const kanban = require("./kanban-client");

// Push cards to the central Kanban board via Hub
await kanban.deployCards([
  {
    title: "Implement data export feature",
    type: "feature",
    priority: "high",
    status: "backlog",
    description: "Add CSV/JSON export for all datasets",
    acceptance_criteria: ["Export button visible on all data views", "Supports CSV and JSON formats"],
  }
]);
\`\`\`

---

_Generated by People Analytics Toolbox Hub on 2026-02-12_
