// ── Kanbai Agent Runner for metric-market ──────────────────
// Claude agent with tool-use that can READ, WRITE, and EDIT code files.
// Requires: npm install @anthropic-ai/sdk
// Anthropic API access - ONE of these (checked in order):
//   1. Replit AI Integration (recommended) — auto-provides AI_INTEGRATIONS_ANTHROPIC_API_KEY
//   2. ANTHROPIC_API_KEY — your own direct Anthropic key
//   DEPLOY_SECRET_KEY  - Shared secret matching the Kanbai instance

const Anthropic = require("@anthropic-ai/sdk");
const fs = require("fs");
const pathMod = require("path");
const { execSync } = require("child_process");
const { pullBoard, claimTask, reportProgress, completeTask, releaseTask, getAvailableTasks, getSchema, getSpokeConfig } = require("./kanbai-connector");

const PROJECT_ROOT = process.cwd();
const KANBAI_URL = "https://cdeb1be5-0bf9-40c9-9f8a-4b50dbea18f1-00-2133qt2hcwgu.picard.replit.dev";
const AGENT_CONFIG = {
  agentId: "agent-metric-market",
  appSlug: "metric-market",
  mode: "semi",
  model: process.env.KANBAI_AGENT_MODEL || "claude-sonnet-4-5",
  pollInterval: 60000,
  maxConcurrent: 1,
  priorities: ["critical", "high", "medium"],
  autoApprove: false,
  maxToolIterations: 15,
  maxFileSize: 200 * 1024,
  commandTimeout: 30000,
  allowedCommands: ["npm test", "npm run lint", "npm run build", "ls", "cat", "grep", "find", "wc", "head", "tail", "diff"],
  blockedPaths: ["node_modules", ".git", ".env", ".replit", "replit.nix", "package-lock.json", ".env.local", ".env.production"],
};

function sanitizePath(filePath) {
  const resolved = pathMod.resolve(PROJECT_ROOT, filePath);
  if (!resolved.startsWith(PROJECT_ROOT + pathMod.sep) && resolved !== PROJECT_ROOT) throw new Error("Path outside project");
  const segments = resolved.split(pathMod.sep);
  for (const b of AGENT_CONFIG.blockedPaths) {
    if (segments.includes(b)) throw new Error("Access denied: " + b);
  }
  return resolved;
}

function isCommandAllowed(cmd) {
  const trimmed = cmd.trim();
  const allowedExact = ["npm test", "npm run lint", "npm run build", "ls", "cat", "grep", "find", "wc", "head", "tail", "diff"];
  if (allowedExact.some(a => trimmed === a || trimmed.startsWith(a + " "))) return true;
  return false;
}

const TOOLS = [
  { name: "read_file", description: "Read file contents", input_schema: { type: "object", properties: { file_path: { type: "string" }, line_start: { type: "integer" }, line_end: { type: "integer" } }, required: ["file_path"] } },
  { name: "write_file", description: "Write/create a file", input_schema: { type: "object", properties: { file_path: { type: "string" }, content: { type: "string" } }, required: ["file_path", "content"] } },
  { name: "edit_file", description: "Replace exact string in a file", input_schema: { type: "object", properties: { file_path: { type: "string" }, old_string: { type: "string" }, new_string: { type: "string" } }, required: ["file_path", "old_string", "new_string"] } },
  { name: "list_directory", description: "List files in a directory", input_schema: { type: "object", properties: { dir_path: { type: "string" } }, required: ["dir_path"] } },
  { name: "search_files", description: "Grep for a pattern across files", input_schema: { type: "object", properties: { pattern: { type: "string" }, dir_path: { type: "string" }, file_glob: { type: "string" } }, required: ["pattern"] } },
  { name: "run_command", description: "Run an allowed shell command", input_schema: { type: "object", properties: { command: { type: "string" } }, required: ["command"] } },
];

function executeTool(name, input) {
  try {
    switch (name) {
      case "read_file": {
        const p = sanitizePath(input.file_path);
        if (!fs.existsSync(p)) return { error: "Not found" };
        if (fs.statSync(p).size > AGENT_CONFIG.maxFileSize) return { error: "File too large" };
        let c = fs.readFileSync(p, "utf-8");
        if (input.line_start || input.line_end) { const ls = c.split("\n"); c = ls.slice(Math.max(0,(input.line_start||1)-1), input.line_end||ls.length).join("\n"); }
        return { content: c, lines: c.split("\n").length };
      }
      case "write_file": {
        const p = sanitizePath(input.file_path);
        const dir = pathMod.dirname(p);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(p, input.content, "utf-8");
        return { success: true, path: input.file_path };
      }
      case "edit_file": {
        const p = sanitizePath(input.file_path);
        if (!fs.existsSync(p)) return { error: "Not found" };
        const c = fs.readFileSync(p, "utf-8");
        if (!c.includes(input.old_string)) return { error: "old_string not found" };
        if ((c.split(input.old_string).length - 1) > 1) return { error: "old_string not unique" };
        fs.writeFileSync(p, c.replace(input.old_string, input.new_string), "utf-8");
        return { success: true, path: input.file_path };
      }
      case "list_directory": {
        const p = sanitizePath(input.dir_path || ".");
        return { entries: fs.readdirSync(p, { withFileTypes: true }).filter(e => !AGENT_CONFIG.blockedPaths.includes(e.name)).map(e => e.name + (e.isDirectory() ? "/" : "")).sort() };
      }
      case "search_files": {
        const dir = sanitizePath(input.dir_path || ".");
        const args = ["-rn"];
        if (input.file_glob) args.push("--include=" + input.file_glob);
        args.push("--", input.pattern, dir);
        try {
          const { execFileSync } = require("child_process");
          const r = execFileSync("grep", args, { cwd: PROJECT_ROOT, timeout: 10000, encoding: "utf-8", maxBuffer: 512*1024 });
          return { results: r.trim().split("\n").filter(Boolean).slice(0,50).map(l => l.replace(PROJECT_ROOT + "/", "")) };
        } catch { return { results: [] }; }
      }
      case "run_command": {
        if (!isCommandAllowed(input.command)) return { error: "Command not allowed" };
        try {
          const r = execSync(input.command, { cwd: PROJECT_ROOT, timeout: AGENT_CONFIG.commandTimeout, encoding: "utf-8", maxBuffer: 512*1024 });
          return { exitCode: 0, output: r.slice(0, 5000) };
        } catch (err) { return { exitCode: err.status || 1, output: (err.stdout||"").slice(0,3000), stderr: (err.stderr||"").slice(0,2000) }; }
      }
      default: return { error: "Unknown tool" };
    }
  } catch (err) { return { error: err.message }; }
}

let anthropic;
let activeTasks = new Map();
let pendingApproval = new Map();
let pendingReview = new Map();
let running = false;

async function executeTaskWithTools(cardId, card) {
  const changeLog = [];
  const filesChanged = {};
  const testResults = [];
  let iter = 0;
  let agentSummary = "";
  const maxIter = AGENT_CONFIG.maxToolIterations;
  const sys = `You are an autonomous AI development agent for "${AGENT_CONFIG.appSlug}".
You have a STRICT budget of ${maxIter} tool-use rounds. Be efficient and produce tangible output.

WORKFLOW:
1. EXPLORE (2-3 rounds max): list_directory and read_file to understand the project
2. IMPLEMENT (remaining rounds): Create or edit files to fulfill the task
3. VERIFY (1-2 rounds): Read modified files or run tests
4. SUMMARIZE: Start your final message with "SUMMARY:" listing what you created/changed

RULES:
- Spend at most 3-4 rounds exploring. Then START implementing.
- Every task must produce at least one tangible artifact (file, code change, documentation)
- If the task is analytical, create an output file with the analysis
- Make focused, minimal changes
- Do NOT edit package.json directly — flag dependency needs in your summary
- When done, start your summary with "SUMMARY:" listing every file created/modified`;
  const taskPrompt = `Task to implement (you have ${maxIter} tool rounds — explore briefly, then implement):\n\nTitle: ${card.title}\nType: ${card.type || "task"}\nPriority: ${card.priority}\nDescription: ${card.description || "None"}\nAcceptance Criteria: ${JSON.stringify(card.acceptanceCriteria || [])}\nTechnical Notes: ${card.technicalNotes || "None"}\nTags: ${(card.tags || []).join(", ")}\n\nBegin by briefly exploring (2-3 rounds), then implement. Produce tangible output.`;
  let messages = [{ role: "user", content: taskPrompt }];

  while (iter < maxIter) {
    iter++;
    await reportProgress(cardId, AGENT_CONFIG.agentId, "in_progress", `Agent working (step ${iter}/${maxIter})`);
    const resp = await anthropic.messages.create({ model: AGENT_CONFIG.model || "claude-sonnet-4-5", max_tokens: 4096, system: sys, tools: TOOLS, messages });
    if (resp.stop_reason === "end_turn" || !resp.content.some(b => b.type === "tool_use")) {
      agentSummary = resp.content.filter(b => b.type === "text").map(b => b.text).join("\n") || "Done";
      changeLog.push("Final: " + agentSummary.slice(0, 500));
      break;
    }
    messages.push({ role: "assistant", content: resp.content });
    const results = [];
    for (const b of resp.content) {
      if (b.type !== "tool_use") continue;
      console.log(`[KanbaiAgent] Tool: ${b.name}(${JSON.stringify(b.input).slice(0,100)})`);
      const r = executeTool(b.name, b.input);
      if (b.name === "read_file") changeLog.push("Read: " + b.input.file_path);
      if (b.name === "list_directory") changeLog.push("Listed: " + (b.input.dir_path || "."));
      if (b.name === "search_files") changeLog.push(`Searched: "${b.input.pattern}" in ${b.input.dir_path || "."}`);
      if (b.name === "write_file" && r.success) {
        changeLog.push("Wrote: " + b.input.file_path);
        filesChanged[b.input.file_path] = { action: "written", size: (b.input.content||"").length };
      }
      if (b.name === "edit_file" && r.success) {
        changeLog.push("Edited: " + b.input.file_path);
        filesChanged[b.input.file_path] = { action: "edited", oldSnippet: (b.input.old_string||"").slice(0,100)+"...", newSnippet: (b.input.new_string||"").slice(0,100)+"..." };
      }
      if (b.name === "run_command") {
        changeLog.push("Ran: " + b.input.command);
        if (b.input.command.startsWith("npm test") || b.input.command.startsWith("npm run lint") || b.input.command.startsWith("npm run build")) {
          testResults.push({ command: b.input.command, exitCode: r.exitCode, output: (r.output||r.error||"").slice(0,1000), passed: r.exitCode === 0 });
        }
      }
      results.push({ type: "tool_result", tool_use_id: b.id, content: JSON.stringify(r).slice(0,10000) });
    }
    messages.push({ role: "user", content: results });
  }

  if (iter >= maxIter && !agentSummary && changeLog.length > 0) {
    agentSummary = `Agent completed ${iter} iterations (budget exhausted). ` +
      (Object.keys(filesChanged).length > 0
        ? `Files modified: ${Object.keys(filesChanged).join(", ")}. `
        : "Explored codebase but made no file changes. ") +
      `Activities: ${changeLog.length} operations performed.`;
    changeLog.push("Reached max iterations (" + maxIter + ")");
  }

  return {
    cardId, agentId: AGENT_CONFIG.agentId, app: AGENT_CONFIG.appSlug,
    iterations: iter, filesChanged, testResults, changeLog,
    summary: agentSummary || changeLog.join("\n"),
    completedAt: new Date().toISOString(),
    hadChanges: Object.keys(filesChanged).length > 0,
    allTestsPassed: testResults.length === 0 || testResults.every(t => t.passed),
  };
}

async function notifyHubCompletion(report) {
  const hubUrl = process.env.HUB_URL || process.env.PLATFORM_HUB_URL;
  if (!hubUrl) return;
  try {
    const resp = await fetch(`${hubUrl}/api/agent-completion`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": process.env.HUB_API_KEY || process.env.DEPLOY_SECRET_KEY || "" },
      body: JSON.stringify(report),
    });
    if (resp.ok) console.log(`[KanbaiAgent] Notified Hub of completion for card #${report.cardId}`);
  } catch (err) { console.log("[KanbaiAgent] Hub notification failed:", err.message); }
}

async function startAgent() {
  const anthropicConfig = {};
  if (process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY) {
    anthropicConfig.apiKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
    if (process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL) anthropicConfig.baseURL = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
    console.log("[KanbaiAgent] Using Replit AI Integration credentials");
  } else if (process.env.ANTHROPIC_API_KEY) {
    console.log("[KanbaiAgent] Using ANTHROPIC_API_KEY");
  } else {
    console.warn("[KanbaiAgent] No Anthropic API key found. Set AI_INTEGRATIONS_ANTHROPIC_API_KEY or ANTHROPIC_API_KEY.");
    return;
  }
  anthropic = new Anthropic(anthropicConfig);
  console.log(`[KanbaiAgent] Starting ${AGENT_CONFIG.agentId} in ${AGENT_CONFIG.mode} mode (with tool-use)`);
  running = true;
  while (running) {
    try {
      if (activeTasks.size < AGENT_CONFIG.maxConcurrent) {
        for (const priority of AGENT_CONFIG.priorities) {
          const { cards } = await getAvailableTasks(priority);
          if (!cards || cards.length === 0) continue;
          const card = cards[0];
          if (AGENT_CONFIG.mode === "semi" && !AGENT_CONFIG.autoApprove) { pendingApproval.set(card.id, card); break; }
          const cr = await claimTask(card.id, AGENT_CONFIG.agentId);
          if (!cr.error || cr.local) activeTasks.set(card.id, { ...card, claimedAt: new Date() });
          break;
        }
      }
      for (const [cardId, card] of activeTasks) {
        try {
          const report = await executeTaskWithTools(cardId, card);
          const summary = report.summary || report.changeLog.join("\n") || "No changes";
          const reportSummary = `${report.iterations} steps | ${Object.keys(report.filesChanged).length} files changed | Tests: ${report.testResults.length === 0 ? "none ran" : report.allTestsPassed ? "all passed" : "some failed"}\n\nFiles: ${Object.keys(report.filesChanged).join(", ") || "none"}\n\n${summary}`;

          if (AGENT_CONFIG.mode === "semi") {
            pendingReview.set(cardId, report);
            await reportProgress(cardId, AGENT_CONFIG.agentId, "review", `Agent finished. Awaiting human review.\n${reportSummary}`);
            console.log(`[KanbaiAgent] #${cardId} queued for review (${report.iterations} steps, ${Object.keys(report.filesChanged).length} files)`);
          } else if (report.hadChanges) {
            await completeTask(cardId, AGENT_CONFIG.agentId, reportSummary);
            await notifyHubCompletion(report);
            console.log(`[KanbaiAgent] Completed #${cardId} (${report.iterations} steps, ${Object.keys(report.filesChanged).length} files)`);
          } else {
            await reportProgress(cardId, AGENT_CONFIG.agentId, "review", `Agent finished but made no file changes. Moving to review.\n${reportSummary}`);
            console.log(`[KanbaiAgent] #${cardId} moved to review (no changes)`);
          }
          activeTasks.delete(cardId);
        } catch (err) {
          console.error(`[KanbaiAgent] Error on #${cardId}:`, err.message);
          await reportProgress(cardId, AGENT_CONFIG.agentId, "in_progress", `Error: ${err.message}`);
        }
      }
    } catch (err) { console.error("[KanbaiAgent] Loop error:", err.message); }
    await sleep(AGENT_CONFIG.pollInterval);
  }
}

function stopAgent() { running = false; }
async function approveTask(cardId) {
  const card = pendingApproval.get(cardId);
  if (!card) throw new Error("No pending task");
  pendingApproval.delete(cardId);
  const cr = await claimTask(card.id, AGENT_CONFIG.agentId);
  if (!cr.error || cr.local) activeTasks.set(card.id, { ...card, claimedAt: new Date() });
}

function registerAgentRoutes(app) {
  app.get("/api/agent/status", (req, res) => {
    res.json({
      agentId: AGENT_CONFIG.agentId, mode: AGENT_CONFIG.mode, running,
      activeTasks: Array.from(activeTasks.entries()).map(([id,c])=>({id,title:c.title})),
      pendingApproval: Array.from(pendingApproval.entries()).map(([id,c])=>({id,title:c.title})),
      pendingReview: Array.from(pendingReview.entries()).map(([id,r])=>({id, filesChanged: Object.keys(r.filesChanged).length, testResults: r.testResults.length, allTestsPassed: r.allTestsPassed})),
    });
  });
  app.post("/api/agent/approve/:cardId", async (req, res) => { try { await approveTask(parseInt(req.params.cardId)); res.json({ success: true }); } catch (err) { res.status(400).json({ error: err.message }); } });
  app.get("/api/agent/review/:cardId", (req, res) => {
    const report = pendingReview.get(parseInt(req.params.cardId));
    if (!report) return res.status(404).json({ error: "No pending review" });
    res.json(report);
  });
  app.post("/api/agent/confirm/:cardId", async (req, res) => {
    try {
      const cardId = parseInt(req.params.cardId);
      const report = pendingReview.get(cardId);
      if (!report) return res.status(404).json({ error: "No pending review" });
      pendingReview.delete(cardId);
      const summary = report.summary || report.changeLog.join("\n");
      await completeTask(cardId, AGENT_CONFIG.agentId, `Confirmed by human review | ${report.iterations} steps | ${Object.keys(report.filesChanged).length} files\n\n${summary}`);
      await notifyHubCompletion(report);
      res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
  });
  app.post("/api/agent/reject-review/:cardId", async (req, res) => {
    try {
      const cardId = parseInt(req.params.cardId);
      const report = pendingReview.get(cardId);
      if (!report) return res.status(404).json({ error: "No pending review" });
      pendingReview.delete(cardId);
      await releaseTask(cardId, AGENT_CONFIG.agentId);
      await reportProgress(cardId, AGENT_CONFIG.agentId, "in_progress", `Human rejected: ${(req.body||{}).reason || "No reason"}`);
      res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
  });
  app.post("/api/agent/start", (req, res) => { if (!running) startAgent(); res.json({ status: "started" }); });
  app.post("/api/agent/stop", (req, res) => { stopAgent(); res.json({ status: "stopped" }); });
  app.post("/api/agent/mode", (req, res) => { const { mode } = req.body||{}; if (mode==="auto"||mode==="semi") { AGENT_CONFIG.mode=mode; AGENT_CONFIG.autoApprove=mode==="auto"; res.json({mode}); } else { res.status(400).json({error:"Invalid mode"}); } });
  app.post("/api/agent/reject/:cardId", async (req, res) => { const id=parseInt(req.params.cardId); const c=pendingApproval.get(id); if(!c) return res.status(404).json({error:"Not found"}); pendingApproval.delete(id); try { await releaseTask(id,AGENT_CONFIG.agentId); } catch {} res.json({success:true}); });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

module.exports = { startAgent, stopAgent, registerAgentRoutes, approveTask, AGENT_CONFIG };
