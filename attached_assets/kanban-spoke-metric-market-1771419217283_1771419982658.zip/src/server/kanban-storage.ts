// Kanban Storage Interface for Spoke Application
// Copy this into your storage layer and implement the methods

import { db } from "./db";
import { eq, and, asc } from "drizzle-orm";
import { kanbanCards, kanbanSubtasks, type KanbanCard, type InsertCard, type KanbanSubtask } from "../shared/kanban-schema";

export class KanbanStorage {
  async getCards(filters?: { appTarget?: string; status?: string }): Promise<KanbanCard[]> {
    const conditions = [];
    if (filters?.appTarget) conditions.push(eq(kanbanCards.appTarget, filters.appTarget));
    if (filters?.status) conditions.push(eq(kanbanCards.status, filters.status));
    if (conditions.length > 0) {
      return db.select().from(kanbanCards).where(and(...conditions)).orderBy(asc(kanbanCards.position));
    }
    return db.select().from(kanbanCards).orderBy(asc(kanbanCards.position));
  }

  async createCard(card: InsertCard): Promise<KanbanCard> {
    const [created] = await db.insert(kanbanCards).values(card).returning();
    return created;
  }

  async updateCard(id: number, data: Partial<InsertCard>): Promise<KanbanCard | undefined> {
    const [updated] = await db.update(kanbanCards).set({ ...data, updatedAt: new Date() }).where(eq(kanbanCards.id, id)).returning();
    return updated;
  }

  async deleteCard(id: number): Promise<boolean> {
    const result = await db.delete(kanbanCards).where(eq(kanbanCards.id, id)).returning();
    return result.length > 0;
  }

  async importFromKanban(cards: any[]): Promise<KanbanCard[]> {
    if (cards.length === 0) return [];
    const mapped = cards.map(c => ({
      ...c,
      sourceApp: "kanban",
      sourceCardId: c.id,
      id: undefined,
      createdAt: undefined,
      updatedAt: undefined,
    }));
    return db.insert(kanbanCards).values(mapped).returning();
  }
}
