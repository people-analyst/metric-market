import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const kanbanCards = pgTable("kanban_cards", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  appTarget: varchar("app_target", { length: 100 }),
  status: varchar("status", { length: 50 }).notNull().default("backlog"),
  priority: varchar("priority", { length: 50 }).notNull().default("medium"),
  description: text("description"),
  acceptanceCriteria: jsonb("acceptance_criteria").$type<string[]>(),
  technicalNotes: text("technical_notes"),
  estimatedEffort: varchar("estimated_effort", { length: 50 }),
  assignedTo: varchar("assigned_to", { length: 100 }),
  dependencies: jsonb("dependencies").$type<string[]>(),
  tags: jsonb("tags").$type<string[]>(),
  agentNotes: text("agent_notes"),
  position: integer("position").default(0),
  sourceApp: varchar("source_app", { length: 100 }),
  sourceCardId: integer("source_card_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const kanbanSubtasks = pgTable("kanban_subtasks", {
  id: serial("id").primaryKey(),
  cardId: integer("card_id").notNull().references(() => kanbanCards.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCardSchema = createInsertSchema(kanbanCards).omit({ id: true, createdAt: true, updatedAt: true });
export const updateCardSchema = insertCardSchema.partial();
export const insertSubtaskSchema = createInsertSchema(kanbanSubtasks).omit({ id: true, createdAt: true });

export type KanbanCard = typeof kanbanCards.$inferSelect;
export type InsertCard = z.infer<typeof insertCardSchema>;
export type KanbanSubtask = typeof kanbanSubtasks.$inferSelect;

export const STATUSES = ["backlog", "planning", "planned", "prioritization", "ready", "assignment", "in_progress", "review", "done"] as const;
export const PRIORITIES = ["critical", "high", "medium", "low"] as const;
