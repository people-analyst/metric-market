# PA Design Kit v1.1

## Overview
Finance-style UI component library for the People Analytics ecosystem. Google/Yahoo Finance aesthetic with information-dense, ticker-first metric displays.

## Installation

1. Copy the `pa-design-kit/` folder to `client/src/components/pa-design-kit/`
2. Install dependencies: `npm install lucide-react recharts`
3. Ensure you have Shadcn UI set up (Card, Badge, Button, Input components)
4. Ensure your project has the `@/lib/utils` module with the `cn()` utility

## Quick Start

```tsx
import {
  MetricTicker,
  StatusDot,
  OutputCard,
  ResultsGrid,
  WorkflowSteps,
  formatMetricValue,
  type OutputCardData,
  type WorkflowStep,
} from "@/components/pa-design-kit";
```

## Components

### Display Components
- **MetricTicker** — Compact single-line metric: label → value → delta → sparkline
- **MetricCard** — Expandable metric tile with trend indicator
- **MetricGrid** — Grid container for tickers/cards
- **MiniSparkline** — Inline SVG sparkline for trend visualization
- **TrendIndicator** — Delta arrow with percent display (green up, red down)
- **IndexGauge** — Ring progress gauge for index scores
- **StatusDot** — Health/status dot indicator (online/degraded/offline)
- **AlertRow** — Compact alert display row
- **SectionHeader** — Section header with icon + count badges

### Data Display Components (v1.1)
- **OutputCard** — Compact result/output item with title, subtitle, status badge, tags, metadata, timestamp
- **ResultsGrid** — Searchable, filterable infinite-scroll list of OutputCards
- **WorkflowSteps** — Iconic workflow position indicators with status dots

### Utilities
- **formatMetricValue()** — Formats numbers as currency, percent, count, or compact notation
- **CLASSIFICATION_STYLES** — Signal color mappings (normal/watch/alert/critical)

## Design Principles

1. **Density over decoration** — Compact layouts, no hero sections
2. **Ticker-first** — Metrics as compact ticker rows, not big stat cards
3. **Delta awareness** — Every value shows directional change
4. **Consistent hierarchy** — Three text levels (primary/secondary/tertiary)
5. **Dark/light parity** — All colors use semantic tokens

See `PA_Design_System_v1.md` for the full specification.

## Peer Dependencies
- React 18+
- Tailwind CSS
- Shadcn UI (Card, Badge, Button, Input, Skeleton)
- lucide-react
- recharts (for sparklines)
