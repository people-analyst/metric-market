// ════════════════════════════════════════════════════════════════════
// Kanbai Unified Bundle for metric-market
// ════════════════════════════════════════════════════════════════════
// ONE FILE. Just paste this into your Replit project as "kanbai-metric-market.js"
// Then add ONE line to your main server file:
//
//   require("./kanbai-metric-market").mount(app);
//
// Required Replit Secrets:
//   DEPLOY_SECRET_KEY  - Shared secret (must match the Kanbai instance)
//                        If you already have this from a previous Kanbai setup, keep using it.
//   ANTHROPIC_API_KEY  - Your Claude API key (optional, only for agent runner)
//                        If you already have this set, no changes needed — your existing key works.
//
// Connector v2.0.0 | Generated 2026-02-17T23:31:41.797Z
// ════════════════════════════════════════════════════════════════════

const KANBAI_URL = "http://cdeb1be5-0bf9-40c9-9f8a-4b50dbea18f1-00-2133qt2hcwgu.picard.replit.dev";
const DEPLOY_SECRET = process.env.DEPLOY_SECRET_KEY;
const CONNECTOR_VERSION = "2.0.0";
const APP_SLUG = "metric-market";

// ── Helper ──────────────────────────────────────────────────────────
const headers = () => ({
  "Content-Type": "application/json",
  "Authorization": `Bearer ${DEPLOY_SECRET}`,
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ════════════════════════════════════════════════════════════════════
// SECTION 1: CONNECTOR  (pull cards, push cards, sync)
// ════════════════════════════════════════════════════════════════════

async function pullBoard() {
  const resp = await fetch(`${KANBAI_URL}/api/pull/board/${APP_SLUG}`, { headers: headers() });
  if (!resp.ok) throw new Error("Failed to pull board: " + resp.status);
  return resp.json();
}

async function pullUpdates(since) {
  const resp = await fetch(`${KANBAI_URL}/api/pull/updates?since=${encodeURIComponent(since)}&app=${APP_SLUG}`, { headers: headers() });
  if (!resp.ok) throw new Error("Failed to pull updates: " + resp.status);
  return resp.json();
}

async function getCards(page = 1, limit = 100) {
  const resp = await fetch(`${KANBAI_URL}/api/kanban/cards?app=${APP_SLUG}&page=${page}&limit=${limit}`, { headers: headers() });
  return resp.json();
}

async function pushCards(cards) {
  const resp = await fetch(`${KANBAI_URL}/api/receive-cards`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({
      cards: cards.map(c => ({
        sourceCardId: c.id,
        title: c.title,
        type: c.type || "task",
        appTarget: APP_SLUG,
        status: c.status || "backlog",
        priority: c.priority || "medium",
        description: c.description || "",
        acceptanceCriteria: c.acceptanceCriteria || [],
        technicalNotes: c.technicalNotes || "",
        tags: c.tags || [],
        dependencies: c.dependencies || [],
        version: c.version || 1,
        updatedAt: c.updatedAt || new Date().toISOString(),
      })),
      metadata: { source: APP_SLUG, sourceApp: APP_SLUG, connectorVersion: CONNECTOR_VERSION, pushedAt: new Date().toISOString() },
    }),
  });
  return resp.json();
}

async function checkForUpdates() {
  const resp = await fetch(`${KANBAI_URL}/api/connector/update-check?version=${CONNECTOR_VERSION}&app=${APP_SLUG}`);
  return resp.json();
}

async function registerWebhook(callbackUrl) {
  const resp = await fetch(`${KANBAI_URL}/api/webhooks/register`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({ appSlug: APP_SLUG, callbackUrl }),
  });
  return resp.json();
}

async function reportHealth() {
  const resp = await fetch(`${KANBAI_URL}/api/ecosystem/health`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      app: APP_SLUG,
      status: "healthy",
      connectorVersion: CONNECTOR_VERSION,
      timestamp: new Date().toISOString(),
    }),
  });
  return resp.json();
}

// ════════════════════════════════════════════════════════════════════
// SECTION 2: AGENT TASK LIFECYCLE  (claim, progress, complete)
// ════════════════════════════════════════════════════════════════════

async function claimTask(cardId, agentId) {
  const resp = await fetch(`${KANBAI_URL}/api/agent/claim`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({ cardId, agentId }),
  });
  return resp.json();
}

async function reportProgress(cardId, agentId, status, notes) {
  const resp = await fetch(`${KANBAI_URL}/api/agent/progress`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({ cardId, agentId, status, notes }),
  });
  return resp.json();
}

async function completeTask(cardId, agentId, completionNotes) {
  const resp = await fetch(`${KANBAI_URL}/api/agent/complete`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({ cardId, agentId, completionNotes }),
  });
  return resp.json();
}

async function releaseTask(cardId, agentId) {
  const resp = await fetch(`${KANBAI_URL}/api/agent/release`, {
    method: "POST", headers: headers(),
    body: JSON.stringify({ cardId, agentId }),
  });
  return resp.json();
}

async function getAvailableTasks(priority) {
  const qs = priority ? `&priority=${priority}` : "";
  const resp = await fetch(`${KANBAI_URL}/api/agent/available?app=${APP_SLUG}${qs}`, { headers: headers() });
  return resp.json();
}

async function getSchema() {
  const resp = await fetch(`${KANBAI_URL}/api/kanban/schema`, { headers: headers() });
  return resp.json();
}

// ════════════════════════════════════════════════════════════════════
// SECTION 3: AGENT RUNNER  (Claude-powered autonomous task loop)
// ════════════════════════════════════════════════════════════════════

const AGENT_CONFIG = {
  agentId: "agent-metric-market",
  appSlug: APP_SLUG,
  mode: "semi",
  pollInterval: 60000,
  maxConcurrent: 1,
  priorities: ["critical", "high", "medium"],
  autoApprove: false,
};

let activeTasks = new Map();
let pendingApproval = new Map();
let running = false;

async function startAgent() {
  let Anthropic;
  try { Anthropic = require("@anthropic-ai/sdk"); } catch {
    console.warn("[KanbaiAgent] @anthropic-ai/sdk not installed. Run: npm install @anthropic-ai/sdk");
    console.warn("[KanbaiAgent] Agent runner disabled. Connector and routes still work.");
    return;
  }
  const anthropic = new Anthropic();
  console.log(`[KanbaiAgent] Starting ${AGENT_CONFIG.agentId} in ${AGENT_CONFIG.mode} mode`);
  running = true;

  while (running) {
    try {
      if (activeTasks.size < AGENT_CONFIG.maxConcurrent) {
        for (const priority of AGENT_CONFIG.priorities) {
          const { cards } = await getAvailableTasks(priority);
          if (!cards || cards.length === 0) continue;
          const card = cards[0];
          console.log(`[KanbaiAgent] Found task: #${card.id} "${card.title}" [${card.priority}]`);
          if (AGENT_CONFIG.mode === "semi" && !AGENT_CONFIG.autoApprove) {
            pendingApproval.set(card.id, card);
            break;
          }
          const claimResult = await claimTask(card.id, AGENT_CONFIG.agentId);
          if (!claimResult.error) {
            activeTasks.set(card.id, { ...card, claimedAt: new Date() });
          }
          break;
        }
      }
      for (const [cardId, card] of activeTasks) {
        try {
          await reportProgress(cardId, AGENT_CONFIG.agentId, "in_progress", "Agent analyzing task...");
          const message = await anthropic.messages.create({
            model: "claude-sonnet-4-20250514",
            max_tokens: 2048,
            system: `You are an AI agent working on development tasks for the ${APP_SLUG} application. Analyze kanban cards and determine what work is needed. Respond with JSON: { "summary": "...", "recommendation": "...", "canAutoComplete": boolean, "steps": [...] }`,
            messages: [{ role: "user", content: `Analyze this task:\nTitle: ${card.title}\nType: ${card.type}\nPriority: ${card.priority}\nDescription: ${card.description || "None"}\nAcceptance Criteria: ${JSON.stringify(card.acceptanceCriteria || [])}\nTechnical Notes: ${card.technicalNotes || "None"}\nTags: ${(card.tags || []).join(", ")}\n\nProvide your analysis as JSON.` }]
          });
          const text = message.content[0].type === "text" ? message.content[0].text : "";
          let analysis;
          try {
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : { summary: text.slice(0, 200), recommendation: "Review needed", canAutoComplete: false, steps: [] };
          } catch { analysis = { summary: "Analysis completed", recommendation: "Manual review recommended", canAutoComplete: false, steps: [] }; }
          if (analysis.canAutoComplete && AGENT_CONFIG.mode === "auto") {
            await completeTask(cardId, AGENT_CONFIG.agentId, `Auto-completed: ${analysis.summary}`);
            console.log(`[KanbaiAgent] Completed #${cardId}`);
          } else {
            await reportProgress(cardId, AGENT_CONFIG.agentId, "review", `Ready for review: ${analysis.recommendation}`);
            console.log(`[KanbaiAgent] Moved #${cardId} to review`);
          }
          activeTasks.delete(cardId);
        } catch (err) {
          console.error(`[KanbaiAgent] Error on #${cardId}:`, err.message);
          await reportProgress(cardId, AGENT_CONFIG.agentId, "in_progress", `Agent error: ${err.message}`);
        }
      }
    } catch (err) { console.error("[KanbaiAgent] Loop error:", err.message); }
    await sleep(AGENT_CONFIG.pollInterval);
  }
}

function stopAgent() { running = false; console.log("[KanbaiAgent] Stopping..."); }

// ════════════════════════════════════════════════════════════════════
// SECTION 4: EXPRESS ROUTES  (mount all endpoints in one call)
// ════════════════════════════════════════════════════════════════════

function mount(app) {
  // Health endpoint (required for ecosystem monitoring)
  app.get("/health", (req, res) => {
    res.json({ status: "ok", app: APP_SLUG, connectorVersion: CONNECTOR_VERSION, agent: running });
  });

  // Webhook receiver (Kanbai sends card events here)
  app.post("/api/hub-webhook", (req, res) => {
    const { event, data } = req.body || {};
    console.log(`[Kanbai Webhook] ${event}:`, data?.title || data?.id || "");
    res.json({ received: true });
  });

  // Specifications endpoint (Kanbai ecosystem discovery)
  app.get("/api/specifications", (req, res) => {
    res.json({
      app: APP_SLUG,
      connectorVersion: CONNECTOR_VERSION,
      capabilities: ["pull", "push", "agent", "webhook", "health"],
      endpoints: ["/health", "/api/hub-webhook", "/api/specifications", "/api/agent/status"],
    });
  });

  // Agent control routes
  app.get("/api/agent/status", (req, res) => {
    res.json({
      agentId: AGENT_CONFIG.agentId, mode: AGENT_CONFIG.mode, running,
      activeTasks: Array.from(activeTasks.entries()).map(([id, c]) => ({ id, title: c.title })),
      pendingApproval: Array.from(pendingApproval.entries()).map(([id, c]) => ({ id, title: c.title })),
    });
  });

  app.post("/api/agent/approve/:cardId", async (req, res) => {
    try {
      const card = pendingApproval.get(parseInt(req.params.cardId));
      if (!card) return res.status(400).json({ error: "No pending task with that id" });
      pendingApproval.delete(card.id);
      const result = await claimTask(card.id, AGENT_CONFIG.agentId);
      if (!result.error) activeTasks.set(card.id, { ...card, claimedAt: new Date() });
      res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
  });

  app.post("/api/agent/start", (req, res) => { if (!running) startAgent(); res.json({ status: "started" }); });
  app.post("/api/agent/stop", (req, res) => { stopAgent(); res.json({ status: "stopped" }); });

  app.post("/api/agent/mode", (req, res) => {
    const { mode } = req.body || {};
    if (mode === "auto" || mode === "semi") {
      AGENT_CONFIG.mode = mode;
      AGENT_CONFIG.autoApprove = mode === "auto";
      console.log(`[KanbaiAgent] Mode switched to ${mode}`);
      res.json({ mode, autoApprove: AGENT_CONFIG.autoApprove });
    } else {
      res.status(400).json({ error: "Invalid mode. Use 'auto' or 'semi'." });
    }
  });

  app.post("/api/agent/reject/:cardId", async (req, res) => {
    const cardId = parseInt(req.params.cardId);
    const card = pendingApproval.get(cardId);
    if (!card) return res.status(404).json({ error: "No pending task with that id" });
    pendingApproval.delete(cardId);
    try {
      await releaseTask(cardId, AGENT_CONFIG.agentId);
      res.json({ success: true, message: `Task #${cardId} rejected and released` });
    } catch (err) {
      res.json({ success: true, message: `Task #${cardId} removed from queue` });
    }
  });

  // Proxy routes so the board UI can fetch cards and config via the spoke server
  app.get("/api/kanban/cards", async (req, res) => {
    try {
      const resp = await fetch(`${KANBAI_URL}/api/kanban/cards?app=${APP_SLUG}`, { headers: headers() });
      const data = await resp.json();
      res.json(data);
    } catch (err) {
      res.status(502).json({ error: "Could not reach Kanbai hub", details: err.message });
    }
  });

  app.get("/api/kanban/spoke-config", async (req, res) => {
    try {
      const resp = await fetch(`${KANBAI_URL}/api/kanban/spoke-config?app=${APP_SLUG}`, { headers: headers() });
      const data = await resp.json();
      res.json(data);
    } catch (err) {
      res.status(502).json({ error: "Could not reach Kanbai hub for config", details: err.message });
    }
  });

  // Auto-register webhook on mount
  const appUrl = process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}`
    : process.env.REPL_SLUG
      ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
      : null;
  if (appUrl) {
    registerWebhook(`${appUrl}/api/hub-webhook`).then(() => {
      console.log(`[Kanbai] Webhook registered: ${appUrl}/api/hub-webhook`);
    }).catch(() => {});
  }

  // Report healthy on mount
  reportHealth().catch(() => {});

  console.log(`[Kanbai] metric-market connected to ${KANBAI_URL} (connector v${CONNECTOR_VERSION})`);
}

// ════════════════════════════════════════════════════════════════════
// EXPORTS
// ════════════════════════════════════════════════════════════════════

module.exports = {
  mount,
  pullBoard, pullUpdates, pushCards, getCards, checkForUpdates, registerWebhook, reportHealth,
  claimTask, reportProgress, completeTask, releaseTask, getAvailableTasks, getSchema,
  startAgent, stopAgent,
  CONNECTOR_VERSION, APP_SLUG,
};
