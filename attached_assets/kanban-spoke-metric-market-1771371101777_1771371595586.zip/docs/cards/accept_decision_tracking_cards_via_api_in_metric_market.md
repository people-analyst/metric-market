# Accept Decision Tracking Cards via API in Metric Market

**Type:** feature | **Priority:** medium | **Status:** backlog

**Application:** metric-market

## Description

Build endpoint to receive decision summaries from Decision Wizard as dashboard tracking cards.

## Acceptance Criteria

- [ ] Accept decision summaries

**Tags:** metric-market, decision-wizard, api

---
*Created: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time) | Updated: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time)*
