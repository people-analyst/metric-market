// Kanban API Routes for Spoke Application
// Mount these routes in your Express app

import type { Express } from "express";
import { KanbanStorage } from "./kanban-storage";

const kanbanStorage = new KanbanStorage();

export function registerKanbanRoutes(app: Express) {
  app.get("/api/kanban/cards", async (req, res) => {
    const filters: any = {};
    if (req.query.app) filters.appTarget = req.query.app;
    if (req.query.status) filters.status = req.query.status;
    const cards = await kanbanStorage.getCards(Object.keys(filters).length ? filters : undefined);
    res.json(cards);
  });

  app.post("/api/kanban/cards", async (req, res) => {
    const card = await kanbanStorage.createCard(req.body);
    res.status(201).json(card);
  });

  app.patch("/api/kanban/cards/:id", async (req, res) => {
    const card = await kanbanStorage.updateCard(parseInt(req.params.id), req.body);
    if (!card) return res.status(404).json({ message: "Card not found" });
    res.json(card);
  });

  app.delete("/api/kanban/cards/:id", async (req, res) => {
    const deleted = await kanbanStorage.deleteCard(parseInt(req.params.id));
    if (!deleted) return res.status(404).json({ message: "Card not found" });
    res.json({ message: "Deleted" });
  });

  app.post("/api/kanban/import", async (req, res) => {
    const { cards } = req.body;
    if (!Array.isArray(cards)) return res.status(400).json({ message: "Expected { cards: [...] }" });
    const created = await kanbanStorage.importFromKanban(cards);
    res.status(201).json({ imported: created.length, cards: created });
  });

  app.get("/api/kanban/export", async (req, res) => {
    const cards = await kanbanStorage.getCards();
    res.json({ exportedAt: new Date().toISOString(), cards });
  });
}
