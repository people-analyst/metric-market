# Wire VOI Analysis to Bubble Scatter Cards

**Type:** feature | **Priority:** medium | **Status:** backlog

**Application:** metric-market

## Description

Map PeopleAnalyst's Value of Information results (information value, decision impact) into bubble_scatter card data format.

## Acceptance Criteria

- [ ] VOI results mapped to bubble_scatter

**Tags:** metric-market, people-analyst, voi, phase4

---
*Created: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time) | Updated: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time)*
