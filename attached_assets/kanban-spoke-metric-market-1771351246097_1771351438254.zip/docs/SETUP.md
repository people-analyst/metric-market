# Kanban Spoke Setup Guide for metric-market

## Overview
This package contains everything needed to add Kanban capabilities to your metric-market application. It was generated from Kanbai.

## Quick Setup

### 1. Install Dependencies
```bash
npm install drizzle-orm drizzle-zod @tanstack/react-query @dnd-kit/core @dnd-kit/sortable
```

### 2. Add Schema
Copy `src/shared/kanban-schema.ts` into your project's shared schema directory.

### 3. Push Database Schema
```bash
npm run db:push
```

### 4. Add Routes
Import and register the kanban routes in your Express server:
```typescript
import { registerKanbanRoutes } from "./kanban-routes";
registerKanbanRoutes(app);
```

### 5. Add UI Components
Copy the board and card components into your client source.

### 6. Import Initial Data
Use the included `data/cards.json` to seed your local kanban:
```bash
curl -X POST http://localhost:5000/api/kanban/import \
  -H "Content-Type: application/json" \
  -d '{"cards": <contents of data/cards.json>}'
```

## Syncing with Central Kanban
Cards can be synced bi-directionally between this spoke and the central Kanban system. See `docs/SYNC.md` for details.
