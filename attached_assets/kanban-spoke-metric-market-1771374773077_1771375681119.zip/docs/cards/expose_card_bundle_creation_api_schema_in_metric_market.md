# Expose Card Bundle Creation API Schema in Metric Market

**Type:** feature | **Priority:** medium | **Status:** backlog

**Application:** metric-market

## Description

Expose card bundle creation API schema and supported chart types for survey data.

## Acceptance Criteria

- [ ] API schema documented

**Tags:** metric-market, preference-modeler, api

---
*Created: Sat Feb 14 2026 23:49:06 GMT+0000 (Coordinated Universal Time) | Updated: Sat Feb 14 2026 23:49:06 GMT+0000 (Coordinated Universal Time)*
