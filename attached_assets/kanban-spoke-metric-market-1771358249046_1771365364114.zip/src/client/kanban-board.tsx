// Minimal Kanban Board Component for Spoke Application
// Integrate this into your React application

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

const STATUSES = ["backlog", "planning", "planned", "prioritization", "ready", "assignment", "in_progress", "review", "done"];
const STATUS_LABELS: Record<string, string> = {
  backlog: "Backlog", planning: "Planning", planned: "Planned", prioritization: "Prioritization", ready: "Ready", assignment: "Assignment", in_progress: "In Progress", review: "Review", done: "Done"
};

export function KanbanBoard() {
  const { data: cards = [] } = useQuery({ queryKey: ["/api/kanban/cards"] });

  return (
    <div className="flex gap-4 p-4 overflow-x-auto h-full">
      {STATUSES.map(status => (
        <div key={status} className="flex-shrink-0 w-72">
          <h3 className="font-semibold mb-3 text-sm">{STATUS_LABELS[status]}</h3>
          <div className="space-y-2">
            {(cards as any[]).filter(c => c.status === status).map(card => (
              <Card key={card.id} className="p-3">
                <h4 className="font-medium text-sm">{card.title}</h4>
                <div className="flex gap-1 mt-2">
                  <Badge variant="secondary">{card.priority}</Badge>
                  <Badge variant="outline">{card.type}</Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
