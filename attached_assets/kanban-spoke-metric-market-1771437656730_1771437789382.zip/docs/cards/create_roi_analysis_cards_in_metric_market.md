# Create ROI Analysis Cards in Metric Market

**Type:** feature | **Priority:** medium | **Status:** backlog

**Application:** metric-market

## Description

Build card templates for VOI Calculator's investment return analyses using bullet_bar and stacked_area chart types.

## Acceptance Criteria

- [ ] bullet_bar and stacked_area templates for ROI

**Tags:** metric-market, voi-calculator, roi, phase5

---
*Created: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time) | Updated: Sat Feb 14 2026 23:49:05 GMT+0000 (Coordinated Universal Time)*
