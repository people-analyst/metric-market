const express = require('express');
const router = express.Router();

router.get('/api/metrics', async (req, res) => {
  const { category, sort, limit } = req.query;
  const metrics = await storage.getAppMetrics(undefined, parseInt(limit) || 50);
  res.json(metrics);
});

router.get('/api/metrics/:key/history', async (req, res) => {
  const { key } = req.params;
  const { appId } = req.query;
  const history = await storage.getMetricsByKey(key, appId ? parseInt(appId) : undefined);
  res.json(history);
});

router.get('/api/metrics/screener', async (req, res) => {
  const { category, minValue, maxValue } = req.query;
  const metrics = await storage.getAppMetrics();
  const filtered = metrics.filter(m => {
    if (category && !m.tags?.includes(category)) return false;
    if (minValue && m.value < parseFloat(minValue)) return false;
    if (maxValue && m.value > parseFloat(maxValue)) return false;
    return true;
  });
  res.json(filtered);
});

module.exports = router;
