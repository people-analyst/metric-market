# MetricMarket Dashboard Bundle

## Overview
Yahoo Finance-style HR metrics dashboard with screener, ticker grid, sparklines, and watchlist.

## Installation
1. Copy `metric-market.tsx` to your `client/src/pages/` directory
2. Add the metrics API routes from `metric-market-routes.js` to your Express server
3. Install dependencies: `npm install @tanstack/react-query recharts lucide-react`
4. Register the route in your React router

## Dependencies
- @tanstack/react-query
- recharts
- lucide-react

## API Routes
The `metric-market-routes.js` file provides example Express routes for:
- GET /api/metrics - List all metrics with current values
- GET /api/metrics/:key/history - Get sparkline history for a metric
- GET /api/metrics/screener - Filter metrics by category, threshold
- POST /api/metrics/watchlist - Manage metric watchlist
