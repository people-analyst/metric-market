// Kanban Card Detail Component for Spoke Application
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface KanbanCardProps {
  card: {
    id: number;
    title: string;
    type: string;
    status: string;
    priority: string;
    description?: string;
    appTarget?: string;
  };
  onClick?: () => void;
}

export function KanbanCard({ card, onClick }: KanbanCardProps) {
  return (
    <Card className="hover-elevate cursor-pointer" onClick={onClick}>
      <CardHeader className="p-3 pb-1">
        <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-3 pt-1">
        <div className="flex items-center gap-1 flex-wrap">
          <Badge variant="secondary">{card.priority}</Badge>
          <Badge variant="outline">{card.type}</Badge>
          {card.appTarget && <Badge variant="outline">{card.appTarget}</Badge>}
        </div>
      </CardContent>
    </Card>
  );
}
