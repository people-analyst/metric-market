# Compensation Migration — Status, Ownership, and Next Steps

**Standalone document** — Share via email, drive, etc. No meta-factory repo access required.

**Date**: 2026-02-09  
**BigQuery project**: `pa-market-data-2026`

---

## Overall Intent

- **Move** all HRIS and compensation data–related functionality to Replit applications built for those purposes.
- **Move data** to BigQuery (in progress).
- **Once confirmed** that data is stood up correctly and code functionality has been assumed by dedicated apps, **clean out** those packages and data from meta-factory (Cursor workspace).

## What a Claude Agent Already Did

A Claude agent built a market compensation data pipeline. Summary:

| Deliverable | Status |
|------------|--------|
| BigQuery project `pa-market-data-2026` | Active; ~5M rows loaded |
| Raw tables (Radford, CompAnalyst, Mercer) | Loaded |
| Discovery views | Working |
| Canonical mapping views | First-pass (CASE-based; need explicit tables) |
| Canonized views | Working |
| Analysis views (`regression_ready`, `pay_by_function_level`) | Working |
| Loader scripts, SQL | In meta-factory (to be migrated) |
| Canonical structure (23 levels, 18 super functions) | Documented |

**Still in meta-factory (temporary)**: Raw CSV files (~6.3GB), loader scripts, SQL, TypeScript packages.

## Splinter Exit Plan — Where We Are

| Cluster | Target | Status |
|---------|--------|--------|
| AnyComp + VOI | Replit (AnyComp) | In progress |
| Segmentation | Replit (Segmentation Studio) | Not started |
| Client onboarding + HR metrics | Replit (Segmentation Studio / Conductor) | Not started |
| Market data backend | Replit or separate backend repo | Not started |
| Data-consolidator | With market data backend | Not started |

## Suggested Ownership and Next Steps

### Conductor
**Owns**: BQ query interface, mapping dashboards, validation/approval workflows.
**Next**: Connect to `pa-market-data-2026`; provide query interface; build mapping review dashboards.

### AnyComp
**Owns**: Pay range modeling, job pricing engine, client-facing outputs.
**Next**: Consume `analysis.regression_ready` and `pay_by_function_level`; port compensation-modeling logic; implement job pricing engine.

### Market Data Backend
**Owns**: Loaders, SQL, canonical mapping tables, job-matching, variableizer.
**Next**: Migrate loaders/SQL; build explicit mapping tables; CompAnalyst job matching; Mercer cleanup; publish shared metadata.

### Meta-Factory
**Owns**: Coordination, handoffs, cleanup after confirmation.
**Next**: Relay docs; get confirmations; remove packages when migration confirmed.

## What Needs Work — Suggested Owners

| Item | Owner |
|------|-------|
| Canonical mapping tables | Market Data Backend |
| CompAnalyst job matching | Market Data Backend |
| Mercer function cleanup | Market Data Backend |
| BQ query interface + dashboards | Conductor |
| Pay range modeling | AnyComp |
| Migrate SQL/loaders | Market Data Backend |

## Shared Metadata

May remain shared (one source of truth): Job structures, canonical segmentation reference, core types.
