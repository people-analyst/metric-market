# Questions for Replit Agents — Relay and Bring Back Answers

**Standalone document** — Copy the questions for each app, relay them, capture answers, and bring back to update status. No meta-factory repo access required.

---

## For AnyComp

1. Do you have (or can you obtain) access to BigQuery project `pa-market-data-2026`? Do you need a service account, credentials, or an API layer instead of direct BQ access?
2. Will you query `analysis.regression_ready` and `analysis.pay_by_function_level` directly from BigQuery, or do you expect a separate API to serve pay ranges and job pricing?
3. Have you reviewed the compensation-modeling package? What have you adopted or ported? What do you still need?
4. How does your Value-of-Information flow (EVPI, EVSI) integrate with market pay data?
5. When do you expect "we have what we need and we're running" for pay range modeling and job pricing? What blockers exist?

---

## For Conductor

1. Do you have (or can you obtain) access to BigQuery project `pa-market-data-2026`?
2. Do you already expose `pipeline`, `mapping`, and `analysis` datasets, or is that on your roadmap? Timeline?
3. Are you planning dashboards for reviewing and approving canonical mappings? Who would own the approval workflow?
4. How do your HR metrics and job structure definitions align with the pipeline's canonical structure (23 levels, 18 super functions, geography)? Any conflicts?
5. When do you expect "we have what we need and we're running" for the BQ query interface and mapping review? What blockers exist?

---

## For Market Data Backend

1. Is there an active Replit project or GitHub repo for this? If not, when do you expect to stand it up?
2. Are you ready to take ownership of the loader scripts and SQL? Where would that code live?
3. Who will build the explicit mapping tables? Do you need Conductor's approval workflow first?
4. Does job-matching-factory cover CompAnalyst job matching (~3,400 codes), or is new logic needed?
5. When will job structures, canonical-segmentation, and variableizer reference be published as shared API or JSON? Who consumes them today?

---

## For PeopleAnalyst

1. Do you consume market pay data for Monte Carlo or VOI? From where?
2. Have you coordinated with AnyComp and VOI Calculator so VOI logic is not duplicated?

---

## For VOI Calculator

1. Do you consume regression results or pay ranges for EVPI/EVSI? From BigQuery, AnyComp, or another source?
2. Have you coordinated with AnyComp and PeopleAnalyst on VOI so there is a single implementation?

---

## For Segmentation Studio

1. Does your canonical field library and Segmentation Pack align with the pipeline structure (S1–E6 levels, 18 super functions, geography)? Any conflicts?
2. Are you consuming or contributing to a shared canonical-segmentation reference? Where does it live?

---

## Cross-cutting (for any agent)

1. What is blocking you from absorbing your part of the compensation/market-data work?
2. What do you need from another Replit app or from meta-factory before you can proceed?
3. What is your best estimate for "we have what we need and we're running"?
