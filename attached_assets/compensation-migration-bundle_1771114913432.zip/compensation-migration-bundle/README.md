# Compensation Migration Bundle — For External Sharing

**Purpose**: Share this bundle with people outside Cursor (Replit teams, contractors, etc.) who may not have access to the meta-factory repo. Everything they need is self-contained.

---

## What's in this bundle

| File | Contents |
|------|----------|
| **COMPENSATION_MIGRATION_BUNDLE.md** | Single file with everything — status, ownership, per-app context, questions. **Use this for most sharing.** |
| **01_Status_And_Ownership.md** | Standalone status doc (same content as Part 1 of the bundle) |
| **02_Data_Pipeline_Context_By_App.md** | Per-app sections — copy the one for your app |
| **03_Questions_For_Replit_Agents.md** | Questions to relay and bring back answers |

---

## How to share

### Option 1: Single file (simplest)
- Send **COMPENSATION_MIGRATION_BUNDLE.md** via:
  - Email attachment
  - Google Drive / Dropbox / OneDrive
  - Slack / Teams
  - Notion / Confluence (paste or import)

### Option 2: ZIP the folder
- Zip the entire `compensation-migration-bundle` folder
- Share the ZIP via email, drive, etc.
- Recipients can extract and use individual files if they prefer

### Option 3: GitHub (if they have access)
- If the meta-factory repo is on GitHub and they have access:
  - Direct link: `https://github.com/people-analyst/meta-factory/blob/main/docs/replit-handoffs/compensation-migration-bundle/COMPENSATION_MIGRATION_BUNDLE.md`
  - Or: `https://github.com/people-analyst/meta-factory/tree/main/docs/replit-handoffs/compensation-migration-bundle`

### Option 4: Per-app
- If sharing with one team only, copy the relevant section from **02_Data_Pipeline_Context_By_App.md** (e.g. Conductor section) into an email or doc.

---

## No repo access required

All content is self-contained. Recipients do not need:
- Access to the meta-factory GitHub repo
- Access to Cursor or the meta-factory workspace
- Any other internal links or files

The only external reference is the BigQuery project name: `pa-market-data-2026`.
