# Market Compensation Data Pipeline — Context by Replit App

**Standalone document** — Copy the section for your app and paste it into your Replit project. No meta-factory repo access required.

**BigQuery project**: `pa-market-data-2026`

---

################################################################################
# ANYCOMP
################################################################################

**Your role**: Pay range modeling from regression results, job pricing engine, client-facing compensation outputs.

**BigQuery**: Dataset `analysis`. Key views: `analysis.regression_ready` (1.49M rows), `analysis.pay_by_function_level`, `analysis.all_sources_canonized`.

**Canonical structure**: 23 levels (S1–E6), 18 super functions, geography hierarchy. Align to this.

**What you need to do**: Connect to BQ; use `regression_ready` for pay modeling; port compensation-modeling logic; consume shared metadata; align VOI with PeopleAnalyst and VOI Calculator.

**Status**: 5M rows loaded; Radford + Mercer mapped; regression-ready validated. CompAnalyst needs job title matching.

---

################################################################################
# CONDUCTOR
################################################################################

**Your role**: BigQuery query interface, mapping table review dashboards, validation/approval workflows.

**BigQuery**: Datasets `pipeline`, `mapping`, `analysis`. Expose raw tables, canonized views, discovery views, mapping views, analysis views.

**What you need to do**: Connect to BQ; provide query interface; build mapping review dashboards; align HR metrics with canonical segmentation.

**Status**: 5M rows in BQ; discovery and mapping views working. Need: explicit mapping tables; CompAnalyst matching; Mercer cleanup.

---

################################################################################
# MARKET DATA BACKEND
################################################################################

**Your role**: Loader scripts, SQL view definitions, canonical mapping tables, job-matching, variableizer.

**To migrate**: Python loader, TypeScript loaders, 22 SQL files, canonical-segmentation-mappings.json, job-structure-alignment.json, variableizer-master.csv, packages (compensation-modeling, variableizer, job-matching-factory).

**What you need to do**: Migrate loaders/SQL; build explicit mapping tables (~1,176 values); CompAnalyst job matching (~3,400 codes); Mercer cleanup; industry/company size canonicalization; publish shared metadata.

Conductor and AnyComp depend on you.

---

################################################################################
# PEOPLEANALYST
################################################################################

**Your role**: Monte Carlo, VOI/EVPI/EVSI, importance scoring, alignment.

**Relevant views**: `analysis.regression_ready`, `analysis.pay_by_function_level`. Consume from BQ or coordinate with AnyComp. Align with AnyComp and VOI Calculator.

---

################################################################################
# VOI CALCULATOR
################################################################################

**Your role**: Value-of-information, EVPI, EVSI for compensation decisions.

Consume regression results or pay ranges via AnyComp or shared API. Align with AnyComp and PeopleAnalyst.

---

################################################################################
# DECISION WIZARD
################################################################################

**Your role**: Structured decision support for compensation.

Pay ranges and job pricing flow from AnyComp. Consume segment definitions via shared metadata APIs.

---

################################################################################
# SEGMENTATION STUDIO
################################################################################

**Your role**: HRIS → canonical fields → Segmentation Pack + Employee Snapshot.

Align with pipeline structure: S1–E6 levels, 18 super functions, geography hierarchy. Shared metadata (canonical segmentation) may have one source of truth.
