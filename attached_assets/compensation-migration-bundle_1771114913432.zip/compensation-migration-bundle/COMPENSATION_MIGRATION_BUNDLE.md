# Compensation Migration — Complete Bundle (Self-Contained)

**For external sharing**: This document is self-contained. Share via email, Google Drive, Slack, or any other channel. Recipients do not need access to the meta-factory repo or Cursor workspace.

**Date**: 2026-02-09  
**BigQuery project**: `pa-market-data-2026`

---

# Part 1: BigQuery Pipeline Overview

A Claude agent built a market compensation data pipeline. Summary of what exists.

## Vision

Build a unified, analysis-ready dataset of market compensation data from three commercial survey sources (Radford, CompAnalyst, Mercer). Every observation is mapped to a canonical structure of job level, job function, geography, and segmentation — enabling multivariate regression on base pay and cross-source comparison.

## BigQuery Project: pa-market-data-2026

### Raw Data Tables

| Table | Rows | Source | Description |
|-------|------|--------|-------------|
| `pipeline.raw_pay_reloaded` | 2,850,000 | Radford | MQ_* survey files |
| `pipeline.raw_pay_companalyst` | 1,982,565 | CompAnalyst | Group_by_job_* files |
| `pipeline.raw_pay_mercer` | 199,798 | Mercer | ListReports_* files |
| **Total** | **5,032,363** | | |

### Discovery Views (mapping dataset)

| View | Purpose |
|------|---------|
| `mapping.radford_jobs` | All Radford job codes with counts and pay stats |
| `mapping.radford_segments` | All distinct dimension values |
| `mapping.companalyst_jobs`, `companalyst_segments` | Same for CompAnalyst |
| `mapping.mercer_jobs`, `mercer_segments` | Same for Mercer |

### Canonical Mapping Views (mapping dataset)

| View | Source Values | Notes |
|------|--------------|-------|
| `mapping.radford_level_to_canonical` | 56 levels | Clean |
| `mapping.radford_function_to_canonical` | 30 functions | "Corporate & Business Services" (228K rows) → "Other" |
| `mapping.radford_geo_to_canonical` | 155 locations | Works but not editable |
| `mapping.mercer_level_to_canonical` | 39 levels | Clean |
| `mapping.mercer_function_to_canonical` | 361 functions | 133 functions (61K rows) → "Other" |
| `mapping.companalyst_geo_to_canonical` | 188 geographies | Reasonable for US data |

**Note**: These need to be replaced with explicit, editable mapping tables.

### Canonized Views (pipeline dataset)

| View | Rows | Fully Mapped |
|------|------|--------------|
| `pipeline.radford_canonized` | 2.85M | 72% |
| `pipeline.companalyst_canonized` | 1.98M | 0%* |
| `pipeline.mercer_canonized` | 200K | 78% |

*CompAnalyst has no native job_level or job_function — needs job title matching.

### Analysis Views (analysis dataset)

| View | Description |
|------|-------------|
| `analysis.all_sources_canonized` | UNION ALL of all 3 — 5M rows |
| `analysis.regression_ready` | Filtered to rows with all dimensions: 1.49M rows, median base $125K |
| `analysis.pay_by_function_level` | Pay by function × level × region |

### Canonical Structure

**Levels** (23 codes): S1–S5 (Support), P1–P6 (Professional), M1–M6 (Manager), E1–E6 (Executive)

**Super Functions** (18): Software & Technology, IT, Engineering, Data Science, Sales, Marketing, Product, Finance, HR, Legal, Operations, QA, R&D, Customer Success, Professional Services, Healthcare, Executive & Leadership, Other

**Geography**: Country → State → Region (Northeast, South, Midwest, West)

## What's Working

1. All 5M rows loaded into BigQuery
2. First-pass canonical mappings for levels and functions (Radford + Mercer)
3. Geography parsing and mapping for all 3 sources
4. Unified view and regression-ready dataset
5. Pay progression validated: S1 $42K → E6 $651K

## What Needs Work

1. Replace CASE-based mapping views with explicit, editable mapping tables (~1,176 values)
2. CompAnalyst job matching — ~3,400 job codes need level/function via job title
3. Mercer function cleanup — 133 functions (61K rows) → "Other"
4. Industry/Company Size canonicalization (currently passed through as-is)

---

# Part 2: Compensation Migration — Status, Ownership, and Next Steps

## Overall Intent

- **Move** all HRIS and compensation data–related functionality to Replit applications built for those purposes.
- **Move data** to BigQuery (in progress).
- **Once confirmed** that data is stood up correctly and code functionality has been assumed by dedicated apps, **clean out** those packages and data from meta-factory (Cursor workspace).

## Splinter Exit Plan — Where We Are

| Cluster | Target | Status | Notes |
|---------|--------|--------|-------|
| **AnyComp + VOI** | Replit (AnyComp) | In progress | Kicked off |
| **Segmentation** | Replit (Segmentation Studio) | Not started | Handoff ready |
| **Client onboarding + HR metrics** | Replit (Segmentation Studio / Conductor) | Not started | Handoff ready |
| **Market data backend** | Replit or separate backend repo | Not started | BigQuery pipeline is the operational path |
| **Data-consolidator** | With market data backend | Not started | Design/docs only |

## Suggested Ownership and Next Steps

### Conductor (Replit)

**Owns**: BigQuery query interface, mapping table review dashboards, validation/approval workflows.

**Next steps**:
1. Connect to BigQuery project `pa-market-data-2026`.
2. Provide query interface for `pipeline.*`, `mapping.*`, `analysis.*` datasets.
3. Build dashboards for reviewing canonical mapping views and (once they exist) explicit mapping tables.
4. Implement validation/approval flows for mapping changes.

### AnyComp (Replit)

**Owns**: Pay range modeling from regression results, job pricing engine, client-facing outputs.

**Next steps**:
1. Consume `analysis.regression_ready` and `analysis.pay_by_function_level` from BigQuery (or via API).
2. Port or replace compensation-modeling logic for pay ranges and variable classification.
3. Implement job pricing engine using canonical level/function/geo.
4. Confirm VOI/EVPI/EVSI flows work with BQ-backed market data.

### Market Data Backend (future Replit project or repo)

**Owns**: Loaders, SQL view definitions, canonical mapping table definitions, job-matching and variableizer logic.

**Next steps**:
1. Migrate loader scripts (Python + TypeScript) and SQL to this project or a dedicated GitHub repo.
2. Build explicit canonical mapping tables in BigQuery (replace CASE views).
3. Own CompAnalyst job matching (title → level/function).
4. Own Mercer function cleanup.
5. Publish job structures and canonical-segmentation reference as shared metadata for meta-factory and Replit apps.

### Meta-Factory

**Owns**: Coordination, handoffs, and cleanup once migration is confirmed.

**Next steps**:
1. Relay documentation to Conductor, AnyComp, and (when ready) Market Data Backend.
2. Get confirmations: "We have what we need and we're running."
3. When migration is confirmed: remove packages, scripts, and raw CSVs from meta-factory.

## What Needs Work — Suggested Owners

| Item | Suggested owner |
|------|-----------------|
| Canonical mapping tables (replace CASE views) | Market Data Backend |
| CompAnalyst job matching | Market Data Backend |
| Mercer function cleanup | Market Data Backend |
| Industry/Company Size canonicalization | Market Data Backend |
| BQ query interface + mapping dashboards | Conductor |
| Pay range modeling from regression | AnyComp |
| Migrate SQL/loaders to GitHub | Market Data Backend |
| Clean up meta-factory | Meta-Factory (after confirmation) |

## Shared Metadata

These may remain shared (one source of truth, pass-through APIs):
- Job structures / job taxonomy
- Canonical segmentation reference
- Core types (if needed for classification)

---

# Part 3: Data Pipeline Context by App

Copy the section for your app and paste it into your Replit project.

---

## ANYCOMP

**Your role**: Pay range modeling from regression results, job pricing engine, client-facing compensation outputs.

**BigQuery**: Project `pa-market-data-2026`, dataset `analysis`. Key views: `analysis.regression_ready` (1.49M rows), `analysis.pay_by_function_level`, `analysis.all_sources_canonized`.

**Canonical structure**: 23 levels (S1–E6), 18 super functions, geography hierarchy (Country → State → Region). You must align to this.

**What you need to do**:
1. Connect to BigQuery project `pa-market-data-2026` (or consume via API).
2. Use `analysis.regression_ready` as primary input for pay range modeling and job pricing.
3. Port or replace compensation-modeling logic; consume shared metadata (job structures, canonical segmentation) from agreed source.
4. Align VOI with PeopleAnalyst and VOI Calculator.

**Status**: 5M rows loaded; Radford + Mercer fully mapped; regression-ready validated. CompAnalyst needs job title matching; Mercer has 133 functions mapped to "Other".

---

## CONDUCTOR

**Your role**: BigQuery query interface, dashboards for reviewing mapping tables, validation/approval workflows.

**BigQuery**: Project `pa-market-data-2026`, datasets `pipeline`, `mapping`, `analysis`.

**Tables/views to expose**: Raw tables (`raw_pay_reloaded`, `raw_pay_companalyst`, `raw_pay_mercer`), canonized views (`radford_canonized`, etc.), discovery views (`radford_jobs`, `companalyst_jobs`, etc.), mapping views (`radford_level_to_canonical`, etc.), analysis views (`regression_ready`, `pay_by_function_level`).

**What you need to do**:
1. Connect to BigQuery project `pa-market-data-2026`.
2. Provide query interface for `pipeline`, `mapping`, `analysis`.
3. Build dashboards for reviewing canonical mappings; support approval workflows when mapping tables become explicit.
4. Align HR metrics and job structures with canonical segmentation.

**Status**: 5M rows in BQ; discovery and mapping views working; regression-ready subset validated. Need: replace CASE views with explicit tables; CompAnalyst job matching; Mercer cleanup.

---

## MARKET DATA BACKEND

**Your role**: Loader scripts, SQL view definitions, canonical mapping table definitions, job-matching and variableizer logic.

**What exists to migrate**: Core loader (Python), TypeScript loaders, 22 SQL view files (stages 1–6), canonical-segmentation-mappings.json, job-structure-alignment.json, variableizer-master.csv, packages (compensation-modeling, variableizer, job-matching-factory).

**What you need to do**:
1. Migrate loaders and SQL to this project or a dedicated repo.
2. Build explicit canonical mapping tables in BigQuery (~1,176 values).
3. CompAnalyst job matching (~3,400 job codes).
4. Mercer function cleanup (133 functions).
5. Industry/Company Size canonicalization.
6. Publish shared metadata (job structures, canonical-segmentation, variableizer reference).

Conductor and AnyComp depend on you for query interface and regression results.

---

## PEOPLEANALYST

**Your role**: Monte Carlo, VOI/EVPI/EVSI, importance scoring, alignment, survey initiation.

**Relevant views**: `analysis.regression_ready`, `analysis.pay_by_function_level`. Consume from BigQuery or coordinate with AnyComp for aggregated ranges. Align with AnyComp and VOI Calculator so VOI is not duplicated.

---

## VOI CALCULATOR

**Your role**: Value-of-information, EVPI, EVSI for compensation decisions.

Market pay data is in BigQuery. Consume regression results or pay ranges via AnyComp or shared API. Align with AnyComp and PeopleAnalyst so VOI is not duplicated.

---

## DECISION WIZARD

**Your role**: Structured decision support for compensation decisions.

Market pay data in BigQuery; pay ranges and job pricing flow from AnyComp. Consume segment definitions and compensation reference via shared metadata APIs.

---

## SEGMENTATION STUDIO

**Your role**: HRIS → canonical fields → dimensions/nodes → Segmentation Pack + Employee Snapshot.

Align canonical field library and Segmentation Packs with pipeline structure: S1–E6 levels, 18 super functions, geography hierarchy. Shared metadata (canonical segmentation reference) may have one source of truth.

---

# Part 4: Questions for Replit Agents

Copy the questions for each app and relay them. Bring answers back to update status and unblock next steps.

---

## For AnyComp

1. Do you have (or can you obtain) access to BigQuery project `pa-market-data-2026`? Do you need a service account, credentials, or an API layer instead of direct BQ access?
2. Will you query `analysis.regression_ready` and `analysis.pay_by_function_level` directly from BigQuery, or do you expect a separate API to serve pay ranges and job pricing?
3. Have you reviewed the compensation-modeling package? What have you adopted or ported? What do you still need?
4. How does your Value-of-Information flow (EVPI, EVSI) integrate with market pay data?
5. When do you expect "we have what we need and we're running" for pay range modeling and job pricing? What blockers exist?

---

## For Conductor

1. Do you have (or can you obtain) access to BigQuery project `pa-market-data-2026`?
2. Do you already expose `pipeline`, `mapping`, and `analysis` datasets, or is that on your roadmap? Timeline?
3. Are you planning dashboards for reviewing and approving canonical mappings? Who would own the approval workflow?
4. How do your HR metrics and job structure definitions align with the pipeline's canonical structure (23 levels, 18 super functions, geography)? Any conflicts?
5. When do you expect "we have what we need and we're running" for the BQ query interface and mapping review? What blockers exist?

---

## For Market Data Backend

1. Is there an active Replit project or GitHub repo for this? If not, when do you expect to stand it up?
2. Are you ready to take ownership of the loader scripts and SQL? Where would that code live?
3. Who will build the explicit mapping tables? Do you need Conductor's approval workflow first?
4. Does job-matching-factory cover CompAnalyst job matching (~3,400 codes), or is new logic needed?
5. When will job structures, canonical-segmentation, and variableizer reference be published as shared API or JSON? Who consumes them today?

---

## For PeopleAnalyst

1. Do you consume market pay data for Monte Carlo or VOI? From where?
2. Have you coordinated with AnyComp and VOI Calculator so VOI logic is not duplicated?

---

## For VOI Calculator

1. Do you consume regression results or pay ranges for EVPI/EVSI? From BigQuery, AnyComp, or another source?
2. Have you coordinated with AnyComp and PeopleAnalyst on VOI so there is a single implementation?

---

## For Segmentation Studio

1. Does your canonical field library and Segmentation Pack align with the pipeline structure (S1–E6 levels, 18 super functions, geography)? Any conflicts?
2. Are you consuming or contributing to a shared canonical-segmentation reference? Where does it live?

---

## Cross-cutting (for any agent)

1. What is blocking you from absorbing your part of the compensation/market-data work?
2. What do you need from another Replit app or from meta-factory before you can proceed?
3. What is your best estimate for "we have what we need and we're running"?

---

**End of bundle.** Share this file; recipients have everything they need without repo access.
